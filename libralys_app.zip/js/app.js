/**
 * Libralys SPA — API は本番 Render を既定とする（Netlify 静的配信向け）。
 *
 * 【API 接続（すべて Render 絶対 URL。相対 /api/* は使わない）】
 * - GET  POST  /api/texts
 * - GET       /api/ui/top | services | market | dcf | contact | mekiki
 * - GET       /api/md-html/{file}
 * - GET       /api/policy-html
 * - GET       /api/office-email, /api/contact-purposes, /api/mekiki-meta
 * - GET       /api/services-caption, /api/services-html
 * - POST      /api/caption-html, /api/price, /parse_listing, /analyze
 * - GET       /api/system-asset/…（ui-render 経由）
 */
import * as R from "./router.js";
import * as UIR from "./ui-render.js";

const AI_SLUGS = ["ai03", "ai04", "ai05", "ai06", "ai07", "ai08"];

/** Render 上の FastAPI（Netlify からは必ず絶対 URL で叩く） */
export const API_ORIGIN = "https://libralys-api.onrender.com";

/** JSON UI API（/api/ui/…）で描画するページ */
const UI_API_SEGMENT = {
  TOP: "top",
  業務内容: "services",
  市場分析: "market",
  DCFシミュレータ: "dcf",
  お問い合わせ: "contact",
  価格の目利き: "mekiki",
};

let TEXTS = { ja: {}, en: {} };

/**
 * /api/texts が未達でもサイドバー・ナビが生キーにならないよう、
 * backend/libralys_app/site_strings.py のサイト共通部のみを同梱（APIで上書き）。
 */
const TEXTS_SITE_SHELL = {
  ja: {
    brand_company: "ライブラリーズ",
    site_catchphrase: "不動産鑑定 × AI分析",
    brand_tone: "不動産コンサルティング",
    sidebar_pages: "ページ",
    footer_line: "© {company} — 不動産コンサルティング",
    footer_translation_note: "英語表示は参考訳です。",
    breadcrumb_home: "ホーム",
    float_nav_back: "戻る",
    float_nav_top: "トップへ",
    logo_alt: "ロゴ",
    invalid_page: "ページが見つかりません",
    invalid_page_name: "「{name}」は無効です。",
    nav_TOP: "トップ",
    "nav_はじめての方へ": "はじめての方へ",
    nav_業務内容: "業務内容",
    nav_業務の流れ: "業務の流れ",
    nav_AI分析ツール: "AI分析ツール",
    nav_AI評価研究グループ: "AI評価研究グループ",
    nav_価格の目利き: "価格の目利き",
    nav_不動産鑑定士マッチング: "不動産鑑定士マッチング",
    "nav_実績・ケーススタディ": "実績・ケーススタディ",
    nav_会社概要: "会社概要",
    nav_代表プロフィール: "代表プロフィール",
    "nav_AI思想（Methodology）": "AI思想（Methodology）",
    "nav_企業統治（Governance）": "企業統治（Governance）",
    "nav_情報セキュリティ（ISMS相当）": "情報セキュリティ（ISMS相当）",
    "nav_倫理規程・不動産鑑定士職業倫理": "倫理規程・不動産鑑定士職業倫理",
    nav_プライバシー: "プライバシー",
    nav_お問い合わせ: "お問い合わせ",
    nav_市場分析: "市場分析",
    "nav_DCFシミュレータ": "DCFシミュレータ",
  },
  en: {
    brand_company: "Libralys",
    site_catchphrase: "Real estate appraisal × AI analytics",
    brand_tone: "Real estate consulting",
    sidebar_pages: "Pages",
    footer_line: "© {company} — Real estate consulting",
    footer_translation_note: "English is a reference translation.",
    breadcrumb_home: "Home",
    float_nav_back: "Back",
    float_nav_top: "Top",
    logo_alt: "Logo",
    invalid_page: "Page not found",
    invalid_page_name: '"{name}" is not a valid page.',
    nav_TOP: "Home",
    "nav_はじめての方へ": "Getting started",
    nav_業務内容: "Services",
    nav_業務の流れ: "How we work",
    nav_AI分析ツール: "AI analytics tools",
    nav_AI評価研究グループ: "AI valuation research",
    nav_価格の目利き: "Price insight",
    nav_不動産鑑定士マッチング: "Appraiser matching",
    "nav_実績・ケーススタディ": "Cases & studies",
    nav_会社概要: "Company",
    nav_代表プロフィール: "Principal profile",
    "nav_AI思想（Methodology）": "AI methodology",
    "nav_企業統治（Governance）": "Governance",
    "nav_情報セキュリティ（ISMS相当）": "Information security",
    "nav_倫理規程・不動産鑑定士職業倫理": "Ethics & professional code",
    nav_プライバシー: "Privacy",
    nav_お問い合わせ: "Contact",
    nav_市場分析: "Market topics",
    "nav_DCFシミュレータ": "DCF simulator",
  },
};

/** 現在言語・フラット辞書（デバッグ用）。表示は T() が TEXTS を参照。 */
const state = {
  get lang() {
    return lang();
  },
  texts: {},
};

function apiUrl(path) {
  const p = path.startsWith("/") ? path : "/" + path;
  return API_ORIGIN + p;
}

function lang() {
  return R.readSession(R.LANG_KEY, "ja") === "en" ? "en" : "ja";
}

function T(key) {
  const k = String(key);
  const L = lang();
  const row = TEXTS[L];
  const ja = TEXTS.ja;
  return row?.[k] ?? ja?.[k] ?? k;
}

function pageLabel(page) {
  return T("nav_" + page);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/** Streamlit st.markdown 相当の **太字** のみ簡易変換（本文はエスケープ） */
function liteBoldHtml(s) {
  const parts = String(s).split(/\*\*/);
  let out = "";
  for (let i = 0; i < parts.length; i++) {
    out += i % 2 === 1 ? "<strong>" + escapeHtml(parts[i]) + "</strong>" : escapeHtml(parts[i]);
  }
  return out.replace(/\n/g, "<br/>");
}

async function fetchJson(path, opts) {
  try {
    const url =
      typeof path === "string" && (path.startsWith("http://") || path.startsWith("https://"))
        ? path
        : API_ORIGIN + (String(path).startsWith("/") ? path : "/" + path);
    const r = await fetch(url, opts);
    if (!r.ok) {
      throw new Error(path + " " + r.status);
    }
    const text = await r.text();
    return JSON.parse(text);
  } catch (err) {
    console.error("APIエラー:", path, err);
    throw err;
  }
}

function mergeTextMaps(base, extra) {
  return Object.assign({}, base || {}, extra || {});
}

async function loadTexts() {
  const L = lang();
  const url = apiUrl("/api/texts?lang=" + encodeURIComponent(L));
  let data = null;
  let lastErr = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const r = await fetch(url, { method: "GET", headers: { Accept: "application/json" } });
      const raw = (await r.text()).replace(/^\uFEFF/, "");
      if (!r.ok) {
        throw new Error("/api/texts HTTP " + r.status + ": " + raw.slice(0, 200));
      }
      const ct = (r.headers.get("content-type") || "").toLowerCase();
      if (!ct.includes("json") && !/^\s*\{/.test(raw)) {
        throw new Error("/api/texts non-JSON: " + ct);
      }
      data = JSON.parse(raw);
      if (!data || typeof data !== "object") {
        throw new Error("/api/texts invalid JSON shape");
      }
      break;
    } catch (e) {
      lastErr = e;
      await new Promise((res) => setTimeout(res, 350 * (attempt + 1)));
    }
  }
  const shellJa = TEXTS_SITE_SHELL.ja || {};
  const shellEn = TEXTS_SITE_SHELL.en || {};
  if (data && data.ja && data.en) {
    TEXTS.ja = mergeTextMaps(shellJa, data.ja);
    TEXTS.en = mergeTextMaps(shellEn, data.en);
  } else {
    if (lastErr) {
      console.warn("[loadTexts] /api/texts failed; using site shell + empty API map", lastErr);
    }
    TEXTS.ja = mergeTextMaps({}, shellJa);
    TEXTS.en = mergeTextMaps({}, shellEn);
  }
  state.texts = TEXTS[L] || {};
}

async function renderUiFromApi(host, page) {
  const segment = UI_API_SEGMENT[page];
  if (!segment) return false;
  UIR.showLoading(host);
  try {
    const data = await UIR.fetchUiJson(apiUrl, segment, lang(), 18000);
    UIR.renderUIPage(host, data, { escapeHtml, liteBoldHtml, apiUrl, fetchJson, lang, T, getHashPage: R.getHashPage });
    if (segment === "contact") {
      try {
        const em = await fetchJson("/api/office-email");
        UIR.patchOfficeEmail(host, (em && em.email) || "");
      } catch (_) {
        /* optional */
      }
    }
  } catch (e) {
    UIR.showFetchError(host, "ページ読み込みエラー", e, 18000);
  }
  return true;
}

async function setCaptionIframe(ifr, captionKeyOrText) {
  const text = T(captionKeyOrText) || captionKeyOrText;
  const r = await fetch(apiUrl("/api/caption-html"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text }),
  });
  const data = await r.json();
  ifr.srcdoc = data.iframe_srcdoc || "";
}

async function renderMarkdownPage(host, mdFile, infoKey) {
  const data = await fetchJson("/api/md-html/" + encodeURIComponent(mdFile));
  const md = document.createElement("div");
  md.className = "lib-page-md notranslate";
  md.setAttribute("translate", "no");
  md.innerHTML = data.html;
  host.appendChild(md);
  if (infoKey) {
    const ib = document.createElement("div");
    ib.className = "info-box";
    ib.textContent = T(infoKey);
    host.appendChild(ib);
  }
}

async function renderPolicyPage(host, which, infoKey) {
  const data = await fetchJson("/api/policy-html?which=" + encodeURIComponent(which) + "&lang=" + encodeURIComponent(lang()));
  const md = document.createElement("div");
  md.className = "lib-page-md notranslate";
  md.setAttribute("translate", "no");
  md.innerHTML = data.html;
  host.appendChild(md);
  if (infoKey) {
    const ib = document.createElement("div");
    ib.className = "info-box";
    ib.textContent = T(infoKey);
    host.appendChild(ib);
  }
}

function syncSidebarSelect(page) {
  const sel = document.getElementById("nav-select");
  if (!sel) return;
  sel.value = page;
}

function renderHeader(page) {
  const zone = document.getElementById("breadcrumb-zone");
  if (!zone) return;
  if (page === "TOP") {
    zone.innerHTML =
      '<div class="lib-top-brand-strip lib-top-brand-strip--home"><div class="lib-top-brand-strip__text">' +
      '<span class="lib-top-brand-strip__name">' +
      escapeHtml(T("brand_company")) +
      "</span></div></div>";
  } else {
    zone.innerHTML =
      '<nav aria-label="breadcrumb"><a href="' +
      R.getHashHref("TOP") +
      '">' +
      escapeHtml(T("breadcrumb_home")) +
      "</a> / <span>" +
      escapeHtml(pageLabel(page)) +
      "</span></nav>";
  }
}

function scrollMainTop() {
  try {
    window.scrollTo({ top: 0, behavior: "smooth" });
    const m = document.getElementById("main");
    if (m) m.scrollTop = 0;
  } catch {}
}

async function renderServices(host) {
  const sc = await fetchJson("/api/services-caption?lang=" + encodeURIComponent(lang()));
  const cap = document.createElement("iframe");
  cap.className = "caption-frame";
  cap.setAttribute("title", "caption");
  await setCaptionIframe(cap, sc.text);
  const dbg = document.createElement("label");
  dbg.style.display = "flex";
  dbg.style.alignItems = "center";
  dbg.style.gap = "0.35rem";
  dbg.style.fontSize = "0.88rem";
  dbg.innerHTML =
    '<input type="checkbox" id="svc_dbg" disabled /> <span>' + escapeHtml(sc.debug_checkbox_label || "") + "</span>";
  const ifr = document.createElement("iframe");
  ifr.style.width = "100%";
  ifr.style.minHeight = "520px";
  ifr.style.border = "1px solid #e2e8f0";
  ifr.style.borderRadius = "10px";
  ifr.setAttribute("title", "services");
  const sh = await fetchJson("/api/services-html");
  ifr.srcdoc = sh.html || "<p>services-html error: " + escapeHtml(sh.error || "") + "</p>";
  host.appendChild(cap);
  host.appendChild(dbg);
  if (lang() === "en") {
    const enMd = await fetchJson("/api/md-html/services_overview_en.md");
    const enBlock = document.createElement("div");
    enBlock.className = "lib-page-md";
    enBlock.style.margin = "1rem 0";
    enBlock.innerHTML = enMd.html;
    host.appendChild(enBlock);
    const jpExp = document.createElement("details");
    const sm = document.createElement("summary");
    sm.textContent = T("services_jp_expander");
    jpExp.appendChild(sm);
    jpExp.appendChild(ifr);
    host.appendChild(jpExp);
  } else {
    host.appendChild(ifr);
  }
}

function walkBucketLabelJa(mins) {
  const w = Number(mins) || 0;
  if (w <= 0) return "駅徒歩16-20分";
  if (w <= 10) return "駅徒歩10分以内";
  if (w <= 15) return "駅徒歩11-15分";
  if (w <= 20) return "駅徒歩16-20分";
  return "駅徒歩21分以上";
}

/** キーは日本語かつ「11-15」のようなハイフンを含むため、必ず文字列リテラルでクォートする */
const WALK_BUCKET_LABEL_EN = {
  "駅徒歩10分以内": "≤10 min walk",
  "駅徒歩11-15分": "11–15 min walk",
  "駅徒歩16-20分": "16–20 min walk",
  "駅徒歩21分以上": "≥21 min walk",
};

function walkBucketDisplay(wbJa) {
  if (lang() === "en") return WALK_BUCKET_LABEL_EN[wbJa] || wbJa;
  return wbJa;
}

function mekikiBoolKey() {
  return "mekiki_business_tool_open";
}
function mekikiAnKey() {
  return "mekiki_analyzer_open";
}

function readBool(key) {
  return sessionStorage.getItem(key) === "1";
}
function writeBool(key, v) {
  sessionStorage.setItem(key, v ? "1" : "0");
}

function formatPriceMan(v, L) {
  if (v == null || Number.isNaN(Number(v))) return "—";
  const n = Number(v);
  if (L === "en") return n.toLocaleString("en-US", { maximumFractionDigits: 0 });
  return n.toLocaleString("ja-JP", { maximumFractionDigits: 0 });
}

function formatUnit(v, L) {
  if (v == null || Number.isNaN(Number(v))) return "—";
  const n = Number(v);
  if (L === "en") return n.toLocaleString("en-US") + " JPY/㎡";
  return n.toLocaleString("ja-JP") + " 円/㎡";
}

function renderMekikiResult(card, result) {
  const L = lang();
  const discPre = document.getElementById("disclaimerPre");
  if (result.error) {
    card.innerHTML = '<p class="notes-warn" style="margin:0;">' + escapeHtml(result.error) + "</p>";
    if (discPre) discPre.textContent = "";
    return;
  }
  const ulItems = (result.detail_lines || [])
    .map((line) => "<li>" + escapeHtml(line) + "</li>")
    .join("");
  const tableBlock =
    result.table_text && String(result.table_text).trim()
      ? '<div class="block-title">' +
        escapeHtml(L === "en" ? "Comparables (table)" : "近隣事例（表）") +
        '</div><pre class="table-pre">' +
        escapeHtml(result.table_text) +
        "</pre>"
      : "";
  const manLabel = L === "en" ? "JPY m" : "万円";
  card.innerHTML =
    '<div class="price-block">' +
    '<div class="label">' +
    escapeHtml(L === "en" ? "Price" : "価格") +
    '</div><div class="price-num">' +
    escapeHtml(formatPriceMan(result.price, L)) +
    '<span style="font-size:1rem;font-weight:600;"> ' +
    escapeHtml(manLabel) +
    '</span></div><div class="label" style="margin-top:0.75rem;">' +
    escapeHtml(L === "en" ? "Unit price (indicative)" : "単価（参考）") +
    '</div><div class="unit-num">' +
    escapeHtml(formatUnit(result.unit_price, L)) +
    "</div></div>" +
    '<div class="block-title">' +
    escapeHtml(L === "en" ? "Summary" : "サマリー（対象・参照帯・留意点）") +
    '</div><div class="summary-text">' +
    escapeHtml(result.summary_text || "") +
    "</div>" +
    '<div class="block-title">' +
    escapeHtml(L === "en" ? "Why it reads that way" : "詳細理由（そう見える理由）") +
    "</div><ul class=\"detail-list\">" +
    ulItems +
    "</ul>" +
    '<div class="block-title">' +
    escapeHtml(L === "en" ? "Position vs. comparables" : "近隣事例との位置づけ（コメント）") +
    '</div><p class="comment-p">' +
    escapeHtml(result.comment || "") +
    "</p>" +
    tableBlock;
  if (discPre) discPre.textContent = result.disclaimer_markdown || "";
}

async function wireMekikiAnalyzers() {
  const walk = document.getElementById("walk_min");
  const cap = document.getElementById("walk_cap");
  const upd = () => {
    const wb = walkBucketLabelJa(walk && walk.value);
    if (cap) cap.textContent = (lang() === "en" ? "Walk-time bucket: " : "駅距離区分：") + walkBucketDisplay(wb);
  };
  if (walk) walk.addEventListener("input", upd);
  document.querySelectorAll('input[name="mekiki_lang"]').forEach((r) => r.addEventListener("change", upd));
  upd();

  const btnParse = document.getElementById("btnParse");
  if (btnParse) {
    btnParse.addEventListener("click", async () => {
      const raw = document.getElementById("raw_listing").value;
      const r = await fetch(apiUrl("/parse_listing"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ raw_listing: raw, lang: lang() }),
      });
      const data = await r.json();
      const p = data.parsed || {};
      if (p.price_myen != null) document.getElementById("price_myen").value = p.price_myen;
      if (p.area_sqm != null) document.getElementById("area_sqm").value = p.area_sqm;
      if (p.walk_min != null) document.getElementById("walk_min").value = p.walk_min;
      document.getElementById("building_condition").checked = !!p.building_condition;
      if (p.address) document.getElementById("address").value = p.address;
      upd();
    });
  }

  const btnRun = document.getElementById("btnRun");
  if (btnRun) {
    btnRun.addEventListener("click", async () => {
      const sec = document.getElementById("resultSection");
      const card = document.getElementById("resultCard");
      const gerr = document.getElementById("globalError");
      if (gerr) {
        gerr.textContent = "";
        gerr.classList.remove("visible");
      }
      sec.classList.remove("visible");
      card.innerHTML = "";
      btnRun.disabled = true;
      const L = lang();
      const body = {
        lang: L,
        raw_listing: document.getElementById("raw_listing").value,
        price_myen: Number(document.getElementById("price_myen").value),
        area_sqm: Number(document.getElementById("area_sqm").value),
        walk_min: Number(document.getElementById("walk_min").value),
        building_condition: document.getElementById("building_condition").checked,
        address: document.getElementById("address").value,
        region: document.getElementById("region").value,
        road_width_m: Number(document.getElementById("road_width_m").value),
        shape_risk: document.getElementById("shape_risk").value,
        comps_raw: document.getElementById("comps_raw").value,
      };
      try {
        const r = await fetch(apiUrl("/analyze"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        const result = await r.json();
        renderMekikiResult(card, result);
        sec.classList.add("visible");
      } catch {
        if (gerr) {
          gerr.textContent = L === "en" ? "Network error" : "通信エラー";
          gerr.classList.add("visible");
        }
      } finally {
        btnRun.disabled = false;
      }
    });
  }

  document.querySelectorAll(".mekiki-tabs button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const tab = btn.getAttribute("data-tab");
      document.querySelectorAll(".mekiki-tabs button").forEach((b) => b.classList.toggle("active", b === btn));
      document.querySelectorAll(".mekiki-panel").forEach((p) => p.classList.toggle("visible", p.getAttribute("data-panel") === tab));
    });
  });
}

async function renderMekiki(host) {
  const meta = await fetchJson("/api/mekiki-meta");
  const L = lang();
  const biz = readBool(mekikiBoolKey());
  const an = readBool(mekikiAnKey());
  let inner = "";
  inner += '<h1 class="page-title">' + escapeHtml(pageLabel("価格の目利き")) + "</h1>";
  inner += "<h3>" + escapeHtml(T("mekiki_story_h")) + "</h3>";
  inner += '<p><img src="image/mekiki_story_ai.png" alt="" style="max-width:100%;border-radius:10px"/></p>';
  inner += '<div class="lib-page-md">' + liteBoldHtml(T("mekiki_story_body")) + "</div>";

  if (!biz) {
    inner +=
      '<div style="border:2px solid #C9A962;border-radius:14px;padding:20px 22px;margin:6px 0 12px 0;background:linear-gradient(165deg,#FFFFFF 0%,#F7F5F2 55%,#EFEBE4 100%)">' +
      '<div style="font-weight:700;font-size:1.2rem;color:#0F1C2E">' +
      escapeHtml(T("mekiki_subtitle")) +
      '</div><p style="margin:12px 0 0;font-size:0.92rem;color:#334155;line-height:1.65">' +
      T("mekiki_open_hint") +
      "</p></div>" +
      '<p style="font-size:0.82rem;color:#64748b">' +
      escapeHtml(T("mekiki_disclaimer_top")).replace(/\n/g, "<br/>") +
      '</p><button type="button" class="open-gate" data-mk="biz">' +
      escapeHtml(T("mekiki_open_main")) +
      "</button>";
    host.innerHTML = inner;
    host.querySelector(".open-gate").addEventListener("click", () => {
      writeBool(mekikiBoolKey(), true);
      writeBool(mekikiAnKey(), false);
      renderPage("価格の目利き");
    });
    return;
  }

  inner +=
    '<div style="border:1px solid rgba(201,169,98,0.45);border-radius:12px;padding:14px 16px;margin-bottom:10px;background:#FAFAF8">' +
    '<span style="font-weight:700;color:#0F1C2E">' +
    escapeHtml(T("mekiki_subtitle")) +
    '</span><span style="color:#64748b;font-size:0.9rem">' +
    escapeHtml(T("mekiki_status")) +
    "</span></div>" +
    '<button type="button" class="open-gate" data-mk="close" style="margin-bottom:0.75rem">' +
    escapeHtml(T("mekiki_close")) +
    "</button>" +
    '<p style="font-size:0.82rem;color:#64748b">' +
    escapeHtml(T("mekiki_disclaimer_top")).replace(/\n/g, "<br/>") +
    "</p>";

  if (!an) {
    inner +=
      '<div style="margin:10px 0 6px;padding:14px 16px;border-radius:12px;border:1px solid rgba(15,28,46,0.12);background:#fff">' +
      escapeHtml(T("mekiki_inner_hint")) +
      '</div><button type="button" class="open-gate" data-mk="an">' +
      escapeHtml(T("mekiki_open_an")) +
      "</button>";
    host.innerHTML = inner;
    host.querySelector('[data-mk="close"]').addEventListener("click", () => {
      writeBool(mekikiBoolKey(), false);
      writeBool(mekikiAnKey(), false);
      renderPage("価格の目利き");
    });
    host.querySelector('[data-mk="an"]').addEventListener("click", () => {
      writeBool(mekikiAnKey(), true);
      renderPage("価格の目利き");
    });
    return;
  }

  const regOpts = (meta.regions || [])
    .map((r) => "<option>" + escapeHtml(r) + "</option>")
    .join("");
  const shapeOpts = (meta.shapes || [])
    .map((s) => "<option>" + escapeHtml(s) + "</option>")
    .join("");
  inner +=
    '<button type="button" class="open-gate" data-mk="close" style="margin:0.5rem 0">' +
    escapeHtml(T("mekiki_close")) +
    "</button>" +
    '<div class="mekiki-tabs">' +
    '<button type="button" data-tab="in" class="active">' +
    escapeHtml(T("mekiki_tab_in")) +
    '</button><button type="button" data-tab="out">' +
    escapeHtml(T("mekiki_tab_out")) +
    '</button><button type="button" data-tab="dis">' +
    escapeHtml(T("mekiki_tab_dis")) +
    "</button></div>" +
    '<div class="mekiki-panel visible" data-panel="in">' +
    "<h3>" +
    escapeHtml(T("mekiki_sec_prop")) +
    "</h3>" +
    '<fieldset class="mekiki-fieldset"><legend>' +
    escapeHtml(T("mekiki_sec_prop")) +
    '</legend><label class="lbl">' +
    escapeHtml(T("mekiki_raw_lbl")) +
    '</label><textarea id="raw_listing" placeholder="' +
    escapeHtml(T("mekiki_raw_ph")) +
    '"></textarea>' +
    '<p class="hint" style="font-size:0.8rem;color:#64748b">' +
    escapeHtml(L === "en" ? "Paste listing text (optional)." : "「貼り付けから反映」で自動読み取り。") +
    '</p><div class="btn-row"><button type="button" class="btn-secondary" id="btnParse">' +
    escapeHtml(L === "en" ? "Apply paste parse" : "貼り付けから反映") +
    "</button></div></fieldset>" +
    '<fieldset class="mekiki-fieldset"><legend>' +
    escapeHtml(T("mekiki_exp_parse")) +
    '</legend><div class="grid2">' +
    '<div><label class="lbl">' +
    escapeHtml(T("mekiki_price")) +
    '</label><input id="price_myen" type="number" min="0" step="10" value="0" /></div>' +
    '<div><label class="lbl">' +
    escapeHtml(T("mekiki_area")) +
    '</label><input id="area_sqm" type="number" min="0" step="1" value="0" /></div>' +
    '<div><label class="lbl">' +
    escapeHtml(T("mekiki_walk")) +
    '</label><input id="walk_min" type="number" min="0" step="1" value="0" /></div>' +
    '<div><label class="lbl"><input id="building_condition" type="checkbox" /> ' +
    escapeHtml(T("mekiki_bcond")) +
    "</label></div></div>" +
    '<label class="lbl">' +
    escapeHtml(T("mekiki_addr")) +
    '</label><input id="address" type="text" /></fieldset>' +
    "<h3>" +
    escapeHtml(T("mekiki_band_h")) +
    "</h3>" +
    '<label class="lbl">' +
    escapeHtml(T("mekiki_region")) +
    '</label><select id="region">' +
    regOpts +
    '</select><p id="walk_cap" class="hint"></p>' +
    "<h3>" +
    escapeHtml(T("mekiki_more_h")) +
    "</h3>" +
    '<div class="grid2"><div><label class="lbl">' +
    escapeHtml(T("mekiki_road")) +
    '</label><input id="road_width_m" type="number" min="0" step="0.5" value="0" /></div>' +
    '<div><label class="lbl">' +
    escapeHtml(T("mekiki_shape")) +
    '</label><select id="shape_risk">' +
    shapeOpts +
    "</select></div></div>" +
    "<h3>" +
    escapeHtml(T("mekiki_comp_h")) +
    "</h3>" +
    '<p class="hint">' +
    escapeHtml(T("mekiki_comp_cap")) +
    '</p><textarea id="comps_raw" placeholder="' +
    escapeHtml(T("mekiki_comp_ph")) +
    '"></textarea>' +
    '<p class="hint" style="margin-top:0.5rem"><label><input type="radio" name="mekiki_lang" value="ja" ' +
    (L === "ja" ? "checked" : "") +
    ' /> JA</label> <label><input type="radio" name="mekiki_lang" value="en" ' +
    (L === "en" ? "checked" : "") +
    ' /> EN</label></p>' +
    '<button type="button" class="btn-primary" id="btnRun" style="margin-top:0.75rem">' +
    escapeHtml(T("mekiki_run")) +
    "</button></div>" +
    '<div class="mekiki-panel" data-panel="out">' +
    "<h3>" +
    escapeHtml(T("mekiki_res_h")) +
    '</h3><div id="globalError" class="notes-warn" style="display:none;margin:0.5rem 0"></div>' +
    '<div id="resultSection" class="result-wrap"><div id="resultCard" class="result-card"></div>' +
    '<details class="disclaimer"><summary>' +
    escapeHtml(T("mekiki_tab_dis")) +
    '</summary><pre id="disclaimerPre" class="disclaimer-pre"></pre></details></div>' +
    '<div class="mekiki-panel" data-panel="dis">' +
    "<h3>" +
    escapeHtml(T("mekiki_ops_h")) +
    "</h3>" +
    '<div class="lib-page-md">' +
    escapeHtml(T("mekiki_disclaimer_top")).replace(/\n/g, "<br/>") +
    "</div><hr/>" +
    "<h3>" +
    escapeHtml(T("mekiki_save_h")) +
    "</h3>" +
    '<div class="lib-page-md">' +
    escapeHtml(T("mekiki_privacy_note")).replace(/\n/g, "<br/>") +
    "</div>" +
    "<h3>" +
    escapeHtml(T("mekiki_ng_h")) +
    "</h3>" +
    "<p>" +
    escapeHtml(T("mekiki_ng_cap")) +
    "</p><ul>" +
    (meta.ng_words_ja || [])
      .map((w) => "<li>" + escapeHtml(w) + "</li>")
      .join("") +
    "</ul></div>";

  host.innerHTML = inner;
  host.querySelector('[data-mk="close"]').addEventListener("click", () => {
    writeBool(mekikiBoolKey(), false);
    writeBool(mekikiAnKey(), false);
    renderPage("価格の目利き");
  });
  document.querySelectorAll('input[name="mekiki_lang"]').forEach((r) => {
    r.addEventListener("change", () => {
      R.writeSession(R.LANG_KEY, r.value);
      renderPage("価格の目利き");
    });
  });
  await wireMekikiAnalyzers();
}

function matchBoolBiz() {
  return "matching_business_tool_open";
}
function matchBoolAn() {
  return "matching_analyzer_open";
}

async function renderMatching(host) {
  const biz = sessionStorage.getItem(matchBoolBiz()) === "1";
  const an = sessionStorage.getItem(matchBoolAn()) === "1";
  let h =
    '<h1 class="page-title">' + escapeHtml(pageLabel("不動産鑑定士マッチング")) + "</h1>" +
    "<h3>" +
    escapeHtml(T("match_story_h")) +
    '</h3><p><img src="image/appraiser_matching_story.png" alt="" style="max-width:100%;border-radius:10px" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'block\'"/><span style="display:none;color:#b45309">' +
    escapeHtml(T("match_story_miss").replace("{path}", "image/appraiser_matching_story.png")) +
    "</span></p>" +
    "<h3>" +
    escapeHtml(T("match_concept_h")) +
    '</h3><div class="lib-page-md">' +
    liteBoldHtml(T("match_concept_body")) +
    "</div>";

  if (!biz) {
    h +=
      '<div style="border:2px solid #C9A962;border-radius:14px;padding:20px 22px;margin:6px 0 12px">' +
      '<div style="font-weight:700;font-size:1.2rem;color:#0F1C2E">' +
      escapeHtml(T("match_subtitle")) +
      '</div><p style="margin:12px 0 0;font-size:0.92rem;color:#334155;line-height:1.65">' +
      T("match_open_hint") +
      '</p></div><p style="font-size:0.82rem;color:#64748b">' +
      escapeHtml(T("matching_disclaimer_top")).replace(/\n/g, "<br/>") +
      '</p><button type="button" class="open-gate" data-mmb="1">' +
      escapeHtml(T("match_open_main")) +
      "</button>";
    host.innerHTML = h;
    host.querySelector(".open-gate").onclick = () => {
      sessionStorage.setItem(matchBoolBiz(), "1");
      sessionStorage.setItem(matchBoolAn(), "0");
      renderPage("不動産鑑定士マッチング");
    };
    return;
  }

  h +=
    '<div style="border:1px solid rgba(201,169,98,0.45);border-radius:12px;padding:14px 16px;margin-bottom:10px;background:#FAFAF8">' +
    '<span style="font-weight:700">' +
    escapeHtml(T("match_subtitle")) +
    '</span><span style="color:#64748b;font-size:0.9rem">' +
    escapeHtml(T("match_status")) +
    "</span></div>" +
    '<button type="button" class="open-gate" data-mmc="1">' +
    escapeHtml(T("mekiki_close")) +
    "</button>" +
    '<p style="font-size:0.82rem;color:#64748b">' +
    escapeHtml(T("matching_disclaimer_top")).replace(/\n/g, "<br/>") +
    "</p>";

  if (!an) {
    h +=
      '<div style="margin:10px 0;padding:14px 16px;border-radius:12px;border:1px solid rgba(15,28,46,0.12)">' +
      escapeHtml(T("match_inner_hint")) +
      '</div><button type="button" class="open-gate" data-mma="1">' +
      escapeHtml(T("match_open_an")) +
      "</button>";
    host.innerHTML = h;
    host.querySelector("[data-mmc]").onclick = () => {
      sessionStorage.setItem(matchBoolBiz(), "0");
      sessionStorage.setItem(matchBoolAn(), "0");
      renderPage("不動産鑑定士マッチング");
    };
    host.querySelector("[data-mma]").onclick = () => {
      sessionStorage.setItem(matchBoolAn(), "1");
      renderPage("不動産鑑定士マッチング");
    };
    return;
  }

  h +=
    '<button type="button" class="open-gate" data-mmc="1" style="margin:0.5rem 0">' +
    escapeHtml(T("mekiki_close")) +
    "</button>" +
    '<div class="mekiki-tabs">' +
    '<button type="button" data-mtab="0" class="active">' +
    escapeHtml(T("mekiki_tab_in")) +
    '</button><button type="button" data-mtab="1">' +
    escapeHtml(T("mekiki_tab_out")) +
    '</button><button type="button" data-mtab="2">' +
    escapeHtml(T("mekiki_tab_dis")) +
    "</button></div>" +
    '<div data-mpanel="0" class="mekiki-panel visible"><h3>' +
    escapeHtml(T("match_in_h")) +
    '</h3><p style="background:#e0f2fe;padding:0.75rem;border-radius:8px">' +
    escapeHtml(T("match_in_info")).replace(/\n/g, "<br/>") +
    '</p><button type="button" id="btnMatchContact">' +
    escapeHtml(T("match_btn_contact")) +
    "</button></div>" +
    '<div data-mpanel="1" class="mekiki-panel"><h3>' +
    escapeHtml(T("match_out_h")) +
    '</h3><p style="background:#e0f2fe;padding:0.75rem;border-radius:8px">' +
    escapeHtml(T("match_out_info")) +
    "</p></div>" +
    '<div data-mpanel="2" class="mekiki-panel"><h3>' +
    escapeHtml(T("match_ops_h")) +
    "</h3>" +
    '<div class="lib-page-md">' +
    escapeHtml(T("matching_disclaimer_top")).replace(/\n/g, "<br/>") +
    "</div><h3>" +
    escapeHtml(T("mekiki_save_h")) +
    '</h3><div class="lib-page-md">' +
    escapeHtml(T("matching_privacy_note")).replace(/\n/g, "<br/>") +
    "</div><h3>" +
    escapeHtml(T("match_note_h")) +
    "</h3><p>" +
    escapeHtml(T("match_note_cap")) +
    "</p></div>";
  host.innerHTML = h;
  host.querySelector("[data-mmc]").onclick = () => {
    sessionStorage.setItem(matchBoolBiz(), "0");
    sessionStorage.setItem(matchBoolAn(), "0");
    renderPage("不動産鑑定士マッチング");
  };
  host.querySelectorAll(".mekiki-tabs button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const i = btn.getAttribute("data-mtab");
      host.querySelectorAll(".mekiki-tabs button").forEach((b) => b.classList.toggle("active", b === btn));
      host.querySelectorAll("[data-mpanel]").forEach((p) => p.classList.toggle("visible", p.getAttribute("data-mpanel") === i));
    });
  });
  document.getElementById("btnMatchContact").onclick = () => {
    R.writeSession(R.NAV_PENDING_KEY, "お問い合わせ");
    R.applyPendingNav();
    renderPage("お問い合わせ").catch(console.error);
  };
}

async function renderContact(host) {
  const cap = document.createElement("iframe");
  cap.className = "caption-frame";
  await setCaptionIframe(cap, "caption_contact");
  const purposes = await fetchJson("/api/contact-purposes?lang=" + encodeURIComponent(lang()));
  const opts = (purposes.options || []).map((o) => "<option>" + escapeHtml(o) + "</option>").join("");
  const inbox = await fetchJson("/api/office-email").catch(() => ({ email: "" }));
  host.appendChild(cap);
  const form = document.createElement("div");
  form.innerHTML =
    '<h3>' +
    escapeHtml(T("contact_purpose")) +
    '</h3><select id="contact_purpose">' +
    opts +
    '</select><div class="grid2" style="margin-top:0.75rem">' +
    '<div><label class="lbl">' +
    escapeHtml(T("contact_name")) +
    '</label><input id="contact_name" type="text" /></div>' +
    '<div><label class="lbl">' +
    escapeHtml(T("contact_email")) +
    '</label><input id="contact_email" type="email" /></div>' +
    '<div><label class="lbl">' +
    escapeHtml(T("contact_tel")) +
    '</label><input id="contact_tel" type="text" /></div>' +
    '<div><label class="lbl">' +
    escapeHtml(T("contact_addr")) +
    '</label><input id="contact_addr" type="text" /></div></div>' +
    '<label class="lbl">' +
    escapeHtml(T("contact_msg")) +
    '</label><textarea id="contact_msg" rows="7" placeholder="' +
    escapeHtml(T("contact_msg_ph")) +
    '"></textarea>' +
    '<p><label><input type="checkbox" id="contact_agree" /> ' +
    escapeHtml(T("contact_agree")) +
    "</label></p>" +
    '<button type="button" id="contact_submit" class="btn-primary">' +
    escapeHtml(T("contact_submit")) +
    '</button><pre id="contact_out" style="display:none;margin-top:1rem;background:#f8fafc;padding:0.75rem;border-radius:8px;font-size:0.82rem"></pre>';
  host.appendChild(form);

  document.getElementById("contact_submit").onclick = () => {
    const name = document.getElementById("contact_name").value.trim();
    const email = document.getElementById("contact_email").value.trim();
    const msg = document.getElementById("contact_msg").value.trim();
    const agree = document.getElementById("contact_agree").checked;
    if (!name || !email || !msg || !agree) {
      alert(T("contact_err_required"));
      return;
    }
    const to = (inbox && inbox.email) || "";
    const purpose = document.getElementById("contact_purpose").value;
    const subj = encodeURIComponent(T("mailto_subj_prefix") + " " + purpose);
    const body = encodeURIComponent(
      [
        T("mailto_body_note"),
        "",
        T("mailto_purpose_lbl") + ": " + purpose,
        T("mailto_name_lbl") + ": " + name,
        T("mailto_email_lbl") + ": " + email,
        T("mailto_tel_lbl") + ": " + (document.getElementById("contact_tel").value || ""),
        T("mailto_addr_lbl") + ": " + (document.getElementById("contact_addr").value || ""),
        "",
        T("mailto_msg_hdr"),
        msg,
      ].join("\n"),
    );
    const out = document.getElementById("contact_out");
    out.style.display = "block";
    out.textContent = JSON.stringify(
      {
        purpose,
        name,
        email,
        submitted_at: new Date().toISOString(),
      },
      null,
      2,
    );
    if (to) {
      window.location.href = "mailto:" + to + "?subject=" + subj + "&body=" + body;
    } else {
      alert(T("contact_info_secrets_setup"));
    }
  };
}

async function renderAiTools(host) {
  const h1 = host.querySelector(".page-title");
  const cap = document.createElement("iframe");
  cap.className = "caption-frame";
  await setCaptionIframe(cap, "caption_ai_tools");
  if (h1 && h1.nextSibling) host.insertBefore(cap, h1.nextSibling);
  else host.appendChild(cap);
  const intro = await fetchJson("/api/md-html/" + (lang() === "en" ? "ai_tools_intro_en.md" : "ai_tools_intro_ja.md"));
  let cards = '<h3 style="margin-top:1rem">' + escapeHtml(T("dash_heading")) + "</h3><div class=\"grid2\">";
  cards +=
    '<div class="news-card"><strong>' +
    escapeHtml(T("ai_ai04_name")) +
    "</strong><p>" +
    escapeHtml(T("ai_ai04_tag")) +
    "</p><p style=\"font-size:0.88rem\">" +
    escapeHtml(T("ai_ai04_sum")) +
    "</p></div>";
  cards +=
    '<div class="news-card"><strong>' +
    escapeHtml(T("ai_ai09_name")) +
    "</strong><p>" +
    escapeHtml(T("ai_ai09_tag")) +
    "</p><p style=\"font-size:0.88rem\">" +
    escapeHtml(T("ai_ai09_sum")) +
    "</p></div></div>";
  cards += "<h3 style=\"margin-top:1.5rem\">Catalog</h3><div class=\"grid2\">";
  for (const slug of AI_SLUGS) {
    cards +=
      '<div class="news-card"><strong>' +
      escapeHtml(T("ai_" + slug + "_name")) +
      "</strong><p>" +
      escapeHtml(T("ai_" + slug + "_tag")) +
      "</p><p style=\"font-size:0.85rem\">" +
      escapeHtml(T("ai_" + slug + "_sum")) +
      "</p></div>";
  }
  cards += "</div>";
  const block = document.createElement("div");
  block.innerHTML = '<div class="lib-page-md">' + intro.html + "</div>" + cards;
  host.appendChild(block);
}

async function renderPage(page) {
  const host = document.getElementById("page-host");
  if (!host) {
    console.error("page-hostが存在しない");
    return;
  }
  host.classList.remove("page-top");
  scrollMainTop();
  renderHeader(page);
  syncSidebarSelect(page);
  document.title = pageLabel(page) + "｜" + T("brand_company");

  if (UI_API_SEGMENT[page]) {
    if (page === "TOP") host.classList.add("page-top");
    await renderUiFromApi(host, page);
    return;
  }

  host.innerHTML = '<h1 class="page-title">' + escapeHtml(pageLabel(page)) + "</h1>";

  if (page === "はじめての方へ") {
    const cap = document.createElement("iframe");
    cap.className = "caption-frame";
    host.appendChild(cap);
    await setCaptionIframe(cap, "caption_hajimete");
    await renderMarkdownPage(host, lang() === "en" ? "hajimete_en.md" : "hajimete_ja.md", null);
    return;
  }
  if (page === "業務の流れ") {
    const cap = document.createElement("iframe");
    cap.className = "caption-frame";
    host.appendChild(cap);
    await setCaptionIframe(cap, "caption_nagare");
    await renderMarkdownPage(host, lang() === "en" ? "flow_en.md" : "flow_ja.md", null);
    return;
  }
  if (page === "AI分析ツール") {
    await renderAiTools(host);
    return;
  }
  if (page === "AI評価研究グループ") {
    const cap = document.createElement("iframe");
    cap.className = "caption-frame";
    host.appendChild(cap);
    await setCaptionIframe(cap, "caption_ai_lab");
    await renderMarkdownPage(host, lang() === "en" ? "ai_research_en.md" : "ai_research_ja.md", "info_ai_lab");
    return;
  }
  if (page === "不動産鑑定士マッチング") {
    await renderMatching(host);
    return;
  }
  if (page === "実績・ケーススタディ") {
    const cap = document.createElement("iframe");
    cap.className = "caption-frame";
    host.appendChild(cap);
    await setCaptionIframe(cap, "caption_cases");
    await renderMarkdownPage(host, lang() === "en" ? "case_en.md" : "case_ja.md", "info_cases");
    return;
  }
  if (page === "会社概要") {
    await renderMarkdownPage(host, lang() === "en" ? "company_en.md" : "company_ja.md", null);
    return;
  }
  if (page === "代表プロフィール") {
    await renderMarkdownPage(host, lang() === "en" ? "profile_en.md" : "profile_ja.md", null);
    return;
  }
  if (page === "AI思想（Methodology）") {
    const cap = document.createElement("iframe");
    cap.className = "caption-frame";
    host.appendChild(cap);
    await setCaptionIframe(cap, "caption_ai_method");
    await renderMarkdownPage(host, lang() === "en" ? "ai_method_en.md" : "ai_method_ja.md", null);
    return;
  }
  if (page === "企業統治（Governance）") {
    const cap = document.createElement("iframe");
    cap.className = "caption-frame";
    host.appendChild(cap);
    await setCaptionIframe(cap, "caption_gov");
    await renderPolicyPage(host, "governance", "info_governance");
    return;
  }
  if (page === "情報セキュリティ（ISMS相当）") {
    const cap = document.createElement("iframe");
    cap.className = "caption-frame";
    host.appendChild(cap);
    await setCaptionIframe(cap, "caption_sec");
    await renderPolicyPage(host, "security", "info_security");
    return;
  }
  if (page === "倫理規程・不動産鑑定士職業倫理") {
    const cap = document.createElement("iframe");
    cap.className = "caption-frame";
    host.appendChild(cap);
    await setCaptionIframe(cap, "caption_ethics");
    await renderPolicyPage(host, "ethics", "info_ethics");
    return;
  }
  if (page === "プライバシー") {
    const cap = document.createElement("iframe");
    cap.className = "caption-frame";
    host.appendChild(cap);
    await setCaptionIframe(cap, "caption_privacy");
    await renderMarkdownPage(host, lang() === "en" ? "privacy_en.md" : "privacy_ja.md", "info_privacy");
    return;
  }
  host.innerHTML =
    '<h1 class="page-title">' +
    escapeHtml(T("invalid_page")) +
    "</h1><p>" +
    escapeHtml(T("invalid_page_name").replace("{name}", page)) +
    "</p>";
}

function fillNavSelect() {
  const sel = document.getElementById("nav-select");
  if (!sel) return;
  sel.innerHTML = "";
  for (const p of R.PAGES) {
    const o = document.createElement("option");
    o.value = p;
    o.textContent = pageLabel(p);
    sel.appendChild(o);
  }
}

function showFatalError(title, err) {
  const msg = String(err && err.stack ? err.stack : err);
  const host = document.getElementById("page-host");
  if (host) {
    host.innerHTML =
      '<div class="lib-top-boot-error" style="padding:1.25rem"><h1 style="color:#b91c1c;margin:0 0 0.75rem">' +
      escapeHtml(title) +
      '</h1><pre style="white-space:pre-wrap;font-size:0.82rem;line-height:1.5">' +
      escapeHtml(msg) +
      "</pre></div>";
  }
  console.error("[app]", title, err);
}

/** Netlify で /mekiki のように直リンクされたとき、ハッシュルータへ寄せる */
function syncPathnameToHash() {
  try {
    const stripped = (location.pathname || "").replace(/\/+$/, "") || "/";
    if (stripped === "/" || stripped === "/index.html") return;
    const seg = stripped.startsWith("/") ? stripped.slice(1) : stripped;
    if (!seg) return;
    const slug = decodeURIComponent(seg).toLowerCase();
    const shortSlugs = new Set(["top", "mekiki", "services", "market", "dcf"]);
    if (!shortSlugs.has(slug)) return;
    const wantHash = "#/" + slug;
    if (location.hash === wantHash) return;
    location.replace(location.origin + "/" + wantHash);
  } catch (_) {
    /* ignore */
  }
}

async function boot() {
  syncPathnameToHash();
  await loadTexts();
  const sb = document.getElementById("sidebar-brand");
  const st = document.getElementById("sidebar-tone");
  const lbl = document.getElementById("lbl-sidebar-pages");
  const fl = document.getElementById("footer-line");
  const ft = document.getElementById("footer-translation-note");
  const fb = document.getElementById("lib-fn-back-btn");
  const ftop = document.getElementById("lib-fn-top-btn");
  if (sb) sb.textContent = T("brand_company");
  const catchEl = document.getElementById("site-catchphrase");
  if (catchEl) catchEl.textContent = T("site_catchphrase");
  if (st) st.textContent = T("brand_tone");
  if (lbl) lbl.textContent = T("sidebar_pages");
  if (fl) fl.textContent = T("footer_line").replace("{company}", T("brand_company"));
  if (ft) ft.textContent = T("footer_translation_note");
  if (fb) fb.textContent = T("float_nav_back");
  if (ftop) ftop.textContent = T("float_nav_top");

  fillNavSelect();

  const langJa = document.getElementById("lang-ja");
  const langEn = document.getElementById("lang-en");
  if (langJa) {
    langJa.disabled = lang() === "ja";
    langJa.onclick = () => {
      R.writeSession(R.LANG_KEY, "ja");
      location.reload();
    };
  }
  if (langEn) {
    langEn.disabled = lang() === "en";
    langEn.onclick = () => {
      R.writeSession(R.LANG_KEY, "en");
      location.reload();
    };
  }

  const navSel = document.getElementById("nav-select");
  if (navSel) {
    navSel.addEventListener("change", (e) => {
      R.setHashPage(e.target.value);
    });
  }

  if (ftop) ftop.onclick = () => scrollMainTop();
  if (fb) {
    fb.onclick = () => {
      const dest = R.popPageHistory();
      R.setHashPage(dest);
    };
  }

  const pending = R.readSession(R.NAV_PENDING_KEY, "");
  if (pending && R.isValidPage(pending)) {
    R.writeSession(R.NAV_PENDING_KEY, "");
    R.setHashPage(pending);
  } else if (!location.hash) {
    R.setHashPage("TOP");
  }
  R.pushPageHistory(R.getHashPage());
  await renderPage(R.getHashPage());

  window.addEventListener("hashchange", async () => {
    const p = R.getHashPage();
    R.pushPageHistory(p);
    await renderPage(p);
  });
}

function runWhenDomReady(fn) {
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn, { once: true });
  else fn();
}

runWhenDomReady(() => {
  boot().catch((e) => showFatalError("起動エラー（boot）", e));
});

