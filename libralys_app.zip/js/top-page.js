/**
 * Streamlit `app.py` TOP ブロックの静的再現（DOM 順・クラス名は Python 出力に追従）。
 * 参照: render_top_hero, render_news_split_tanizawa_style → news_section,
 *       render_real_estate_trends_section, render_top_nav_card_groups（show_group_headers=False）
 */
import * as R from "./router.js";

/** `lib/top_nav_cards.default_top_nav_card_specs` と同一（target_page = カード表記・遷移先） */
const TOP_NAV_CARD_SPECS = [
  { cardId: "nav_top", page: "TOP", preset: 0, desc: "サイト全体の入り口・俯瞰", image: "assets/topnav/topnav-bg-top.png" },
  { cardId: "nav_hajimete", page: "はじめての方へ", preset: 1, desc: "初めての方へのご案内と読み方", image: "assets/topnav/topnav-bg-hajimete.png" },
  { cardId: "nav_gyomu", page: "業務内容", preset: 2, desc: "提供領域とアプローチの要点", image: "assets/topnav/topnav-bg-gyomu.png" },
  { cardId: "nav_nagare", page: "業務の流れ", preset: 3, desc: "ご依頼から成果物までのイメージ", image: "assets/topnav/topnav-bg-nagare.png" },
  { cardId: "nav_ai_tools", page: "AI分析ツール", preset: 4, desc: "参考分析・ローカルデモの入口", image: "assets/topnav/topnav-bg-ai-tools.png" },
  { cardId: "nav_ai_lab", page: "AI評価研究グループ", preset: 5, desc: "検証・研究の位置づけ", image: "assets/topnav/topnav-bg-ai-lab.png" },
  { cardId: "nav_mekiki", page: "価格の目利き", preset: 6, desc: "価格説明支援ツール（業務用）", image: "assets/topnav/topnav-bg-mekiki.png" },
  { cardId: "nav_matching", page: "不動産鑑定士マッチング", preset: 7, desc: "専門家マッチングの考え方", image: "assets/topnav/topnav-bg-matching.png" },
  { cardId: "nav_cases", page: "実績・ケーススタディ", preset: 8, desc: "公開事例・スタディの入口", image: "assets/topnav/topnav-bg-cases.png" },
  { cardId: "nav_kaisha", page: "会社概要", preset: 9, desc: "体制・方針の要約", image: "assets/topnav/topnav-bg-kaisha.png" },
  { cardId: "nav_profile", page: "代表プロフィール", preset: 10, desc: "代表の経歴と実務の軸", image: "assets/topnav/topnav-bg-profile.png" },
];

/** `grouped_default_top_nav_specs` のページ並び */
const TOP_NAV_GROUPS = [
  ["TOP", "はじめての方へ", "会社概要", "代表プロフィール"],
  ["業務内容", "業務の流れ", "実績・ケーススタディ"],
  ["AI分析ツール", "AI評価研究グループ", "価格の目利き", "不動産鑑定士マッチング"],
];

function encAssetRel(rel) {
  return rel.split("/").map(encodeURIComponent).join("/");
}

function liteBoldHtml(s, escapeHtml) {
  const parts = String(s).split(/\*\*/);
  let out = "";
  for (let i = 0; i < parts.length; i++) {
    out += i % 2 === 1 ? "<strong>" + escapeHtml(parts[i]) + "</strong>" : escapeHtml(parts[i]);
  }
  return out.replace(/\n/g, "<br/>");
}

function cardTitle(page, T, lang) {
  return lang() === "en" ? T("nav_" + page) : page;
}

function newsTagClass(category) {
  const c = (category || "").trim().toLowerCase();
  const raw = (category || "").trim();
  if (c.includes("report") || c === "事例" || c === "レポート") return ["REPORT", "lib-news-tag-report"];
  if (c.includes("release") || raw.includes("リリース")) return ["RELEASE", "lib-news-tag-release"];
  if (raw.includes("サイト") || c.includes("site")) return ["SITE", "lib-news-tag-site"];
  if (c.includes("media") || raw.includes("メディア")) return ["MEDIA", "lib-news-tag-media"];
  if (c.includes("event") || raw.includes("イベント")) return ["EVENT", "lib-news-tag-event"];
  if (c.includes("notice") || raw.includes("お知らせ")) return ["NOTICE", "lib-news-tag-notice"];
  if (c.includes("governance") || raw.includes("方針") || raw.includes("統治") || c.includes("policy"))
    return ["POLICY", "lib-news-tag-governance"];
  return [(raw ? raw.slice(0, 8).toUpperCase() : "NEWS"), "lib-news-tag-muted"];
}

function parseNewsDate(s) {
  const t = String(s || "")
    .trim()
    .replace(/\//g, ".")
    .replace(/-/g, ".");
  const parts = t.split(".").filter(Boolean);
  if (parts.length >= 3 && parts.slice(0, 3).every((p) => /^\d+$/.test(p))) {
    const y = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    const d = parseInt(parts[2], 10);
    const dt = new Date(y, m - 1, d);
    if (!isNaN(dt.getTime())) return dt;
  }
  return null;
}

function splitCurrentArchiveNews(items, featured, currentMax) {
  if (!items || !items.length) return [null, [], []];
  if (featured) {
    const feat = items[0];
    const tail = items.slice(1);
    return [feat, tail.slice(0, Math.max(0, currentMax)), tail.slice(Math.max(0, currentMax))];
  }
  return [null, items.slice(0, currentMax), items.slice(currentMax)];
}

function tierBadgeClass(tier) {
  const t = String(tier);
  if (t === "公的") return "lib-trend-badge lib-trend-badge--tier-ko";
  if (t === "業界") return "lib-trend-badge lib-trend-badge--tier-gy";
  return "lib-trend-badge lib-trend-badge--tier-oth";
}

function aiNavBackgroundLayers(preset) {
  const p = ((Number(preset) % 8) + 8) % 8;
  const palettes = [
    [195, 245, 38, 220],
    [265, 290, 48, 200],
    [175, 205, 42, 210],
    [210, 240, 45, 230],
    [155, 185, 40, 195],
    [230, 260, 50, 215],
    [200, 225, 44, 235],
    [185, 215, 36, 205],
  ];
  const [a, b, sat, glow] = palettes[p];
  const core = `linear-gradient(155deg, hsl(${a},${sat}%,16%) 0%, hsl(${b},${sat + 8}%,10%) 48%, #070b12 100%)`;
  const grid =
    "repeating-linear-gradient(0deg, transparent, transparent 18px, rgba(148,200,255,0.04) 18px, rgba(148,200,255,0.04) 19px), " +
    "repeating-linear-gradient(90deg, transparent, transparent 18px, rgba(148,200,255,0.04) 18px, rgba(148,200,255,0.04) 19px)";
  const glowR =
    `radial-gradient(ellipse 90% 60% at 20% 30%, hsla(${glow},55%,45%,0.22) 0%, transparent 55%), ` +
    `radial-gradient(ellipse 70% 50% at 85% 75%, hsla(${a},70%,50%,0.12) 0%, transparent 50%)`;
  const scan = "linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.04) 50%, transparent 60%)";
  return `${core}, ${glowR}, ${grid}, ${scan}`;
}

let _topnavCssOnce = false;

/** `lib/top_nav_cards._topnav_streamlit_key` と同一: topnav_{card_id} */
function topnavStreamlitKey(cardId) {
  return `topnav_${String(cardId).replace(/"/g, "")}`;
}

function injectTopNavCardCss(apiUrl) {
  if (!document.head) {
    console.error("[top-page] injectTopNavCardCss: document.head がありません");
    return;
  }
  if (_topnavCssOnce) return;
  _topnavCssOnce = true;
  const specsFlat = TOP_NAV_GROUPS.flatMap((pages) =>
    pages.map((p) => TOP_NAV_CARD_SPECS.find((s) => s.page === p)).filter(Boolean),
  );
  const featuredIds = new Set(
    TOP_NAV_GROUPS.filter((g) => g.length === 1).map((g) => TOP_NAV_CARD_SPECS.find((s) => s.page === g[0])?.cardId).filter(Boolean),
  );
  const rules = [];
  for (const spec of specsFlat) {
    const tall = featuredIds.has(spec.cardId);
    const mh = tall ? "132px" : "118px";
    const fs = tall ? "clamp(1.02rem, 2.6vw, 1.22rem)" : "clamp(0.95rem, 2.3vw, 1.08rem)";
    const wk = topnavStreamlitKey(spec.cardId);
    const sel = `#page-host.page-top div.st-key-${wk} [data-testid="stButton"] button`;
    const selOn = `#page-host.page-top div.lib-ai-nav-onpage[data-lib-topnav-id="${spec.cardId}"]`;
    let bgImg;
    let bgExtra;
    if (spec.image) {
      const u = apiUrl("/api/system-asset/" + encAssetRel(spec.image));
      bgImg =
        "linear-gradient(155deg, rgba(15,28,46,0) 0%, rgba(7,11,18,0) 52%, rgba(15,28,46,0) 100%), " + `url("${u}")`;
      bgExtra =
        "background-size: auto, cover !important;\n  background-position: center, center !important;\n  background-repeat: no-repeat, no-repeat !important;";
    } else {
      bgImg = aiNavBackgroundLayers(spec.preset);
      bgExtra = "background-blend-mode: normal, normal, normal, normal !important;";
    }
    rules.push(`
${sel},
${selOn} {
  background-color: transparent !important;
  background-image: ${bgImg} !important;
  ${bgExtra}
  min-height: ${mh} !important;
  height: auto !important;
  white-space: normal !important;
  text-align: left !important;
  align-items: flex-start !important;
  justify-content: flex-end !important;
  padding: 1.05rem 1.1rem 1.15rem 1.1rem !important;
  color: #ffffff !important;
  font-weight: 800 !important;
  font-size: ${fs} !important;
  line-height: 1.4 !important;
  letter-spacing: 0.04em !important;
  border: 1px solid rgba(201, 169, 98, 0.55) !important;
  border-radius: 16px !important;
  box-shadow:
    inset 0 0 0 1px rgba(255,255,255,0.06),
    0 16px 48px rgba(15, 28, 46, 0.35),
    0 0 40px rgba(56, 189, 248, 0.06) !important;
  transition: transform 0.14s ease, box-shadow 0.14s ease, border-color 0.14s ease !important;
}
${selOn} {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  text-align: center !important;
  box-sizing: border-box !important;
}
${sel}:hover {
  background-color: transparent !important;
  cursor: pointer !important;
  transform: translateY(-2px);
  box-shadow:
    inset 0 0 0 1px rgba(255,255,255,0.1),
    0 22px 56px rgba(15, 28, 46, 0.42),
    0 0 48px rgba(201, 169, 98, 0.12) !important;
  border-color: rgba(201, 169, 98, 0.85) !important;
}
${sel}:focus-visible {
  outline: 2px solid rgba(201, 169, 98, 0.95) !important;
  outline-offset: 2px !important;
}
@media (max-width: 640px) {
  ${sel} {
    min-height: calc(${mh} + 12px) !important;
    padding: 1.05rem 1rem 1.15rem 1rem !important;
  }
}
${sel} p,
${selOn} p,
${sel} span,
${selOn} span {
  color: #ffffff !important;
  font-size: inherit !important;
  font-weight: 800 !important;
  letter-spacing: inherit !important;
  line-height: inherit !important;
  text-shadow:
    0 1px 0 rgba(15, 28, 46, 0.65),
    0 2px 4px rgba(0, 0, 0, 0.55),
    0 3px 22px rgba(0, 0, 0, 0.95),
    0 0 10px rgba(0, 0, 0, 0.88) !important;
}
`);
  }
  const st = document.createElement("style");
  st.id = "lib-topnav-ai-bg";
  st.textContent = rules.join("\n");
  const prev = document.getElementById("lib-topnav-ai-bg");
  if (prev) prev.replaceWith(st);
  else document.head.appendChild(st);
}

function bindNav(host, selector) {
  try {
    host.querySelectorAll(selector).forEach((btn) => {
      btn.addEventListener("click", () => {
        const dest = btn.getAttribute("data-nav-target");
        if (dest && R.isValidPage(dest)) {
          R.setHashPage(dest);
        }
      });
    });
  } catch (e) {
    console.error("[top-page] bindNav エラー:", e);
  }
}

function buildNewsCardHtml(row, featured, logoImgHtml, linkLabel, escapeHtml) {
  const dEsc = escapeHtml(String(row.date || "—"));
  const [tagTxt, tagCls] = newsTagClass(String(row.category || ""));
  const titleEsc = escapeHtml(String(row.title || ""));
  const bodyHtml = row.body_html || "";
  const cardCls = featured ? "lib-news-card lib-news-card--featured" : "lib-news-card";
  let logoBlock = "";
  if (logoImgHtml && tagCls === "lib-news-tag-site") {
    logoBlock = `<div class="lib-news-detail-logo">${logoImgHtml}</div>`;
  }
  let inner = "";
  if (bodyHtml) {
    inner = `<div class="lib-news-card-body">${logoBlock}${bodyHtml}</div>`;
  } else if (logoBlock) {
    inner = logoBlock;
  }
  let linkHtml = "";
  const link = String(row.link || "").trim();
  if (link.startsWith("http://") || link.startsWith("https://")) {
    linkHtml = `<p class="lib-news-stack" style="margin:0.5rem 0 0"><a href="${escapeHtml(link)}" target="_blank" rel="noopener noreferrer">${escapeHtml(linkLabel)}</a></p>`;
  }
  return `
<div class="${cardCls}">
  <div class="lib-news-card-meta">
    <span>${dEsc}</span>
    <span class="lib-news-tag ${tagCls}">${escapeHtml(tagTxt)}</span>
  </div>
  <h3 class="lib-news-card-title">${titleEsc}</h3>
  ${inner}
</div>
${linkHtml}`;
}

function buildNewsArchiveHtml(items, monthPrefix, logoImgHtml, linkLabel, escapeHtml) {
  const byMonth = new Map();
  for (const row of items) {
    const d = parseNewsDate(String(row.date || ""));
    const ym = d ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}` : "—";
    if (!byMonth.has(ym)) byMonth.set(ym, []);
    byMonth.get(ym).push(row);
  }
  const order = Array.from(byMonth.keys()).sort((a, b) => (a < b ? 1 : a > b ? -1 : 0));
  let html = "";
  for (const ym of order) {
    let monthItems = byMonth.get(ym).slice();
    monthItems.sort((a, b) => {
      const da = parseNewsDate(String(a.date || ""));
      const db = parseNewsDate(String(b.date || ""));
      const oa = da ? da.getTime() : 0;
      const ob = db ? db.getTime() : 0;
      if (ob !== oa) return ob - oa;
      return String(b.title || "").localeCompare(String(a.title || ""));
    });
    html += `<p class="lib-news-archive-month">${escapeHtml(monthPrefix)} ${escapeHtml(ym)}</p>`;
    html += '<div class="lib-news-stack">';
    for (const row of monthItems) {
      html += buildNewsCardHtml(row, false, logoImgHtml, linkLabel, escapeHtml);
    }
    html += "</div>";
  }
  return html;
}

function passTrendFilters(row, catFilter, srcFilter, tAll, tKokudo, tSanki, tReit, tOther, srcMap) {
  if (catFilter !== tAll && String(row.category) !== catFilter) return false;
  const g = srcMap[String(row.source_key || "OTHER")] || "other";
  if (srcFilter === tKokudo && g !== "kokudo") return false;
  if (srcFilter === tSanki && g !== "sanki") return false;
  if (srcFilter === tReit && g !== "reit") return false;
  if (srcFilter === tOther && g !== "other") return false;
  return true;
}

function fmtTrendScore(template, score) {
  const n = Number(score) || 0;
  return String(template).replace("{score:.2f}", n.toFixed(2)).replace("{score}", String(n));
}

function renderTrendDynamic(host, items, T, escapeHtml, langFn) {
  try {
    if (!host) {
      console.error("[top-page] renderTrendDynamic: host が null");
      return;
    }
    const box = host.querySelector("#lib-trend-dynamic");
    if (!box) {
      console.error("[top-page] renderTrendDynamic: #lib-trend-dynamic が見つかりません");
      return;
    }

    const catSel = host.querySelector("#lib_trend_filter_category");
    const srcSel = host.querySelector("#lib_trend_filter_source");
    const catFilter = catSel ? catSel.value : T("trend_cat_all");
    const srcFilter = srcSel ? srcSel.value : T("trend_src_all");
    let srcMap = {};
    try {
      srcMap = JSON.parse(host.dataset.trendSrcMap || "{}");
    } catch (parseErr) {
      console.error("[top-page] trendSrcMap JSON.parse 失敗:", parseErr, host.dataset.trendSrcMap);
      srcMap = {};
    }

    const activeAll = items.filter((r) => !r.archived);
    const archived = items.filter((r) => r.archived);
    const active = activeAll.filter((r) =>
      passTrendFilters(r, catFilter, srcFilter, T("trend_cat_all"), T("trend_src_kokudo"), T("trend_src_sanki"), T("trend_src_reit"), T("trend_src_other"), srcMap),
    );
    const archivedF = archived.filter((r) =>
      passTrendFilters(r, catFilter, srcFilter, T("trend_cat_all"), T("trend_src_kokudo"), T("trend_src_sanki"), T("trend_src_reit"), T("trend_src_other"), srcMap),
    );

    if (!active.length && !archivedF.length) {
      box.innerHTML = `<div class="lib-trend-wrap lib-trend-st-info">${escapeHtml(T("trend_empty"))}</div>`;
      return;
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const spotlight = active.slice(0, 3);
    const rest = active.slice(3);

    let html = "";
    html += `<div class="lib-trend-wrap"><p class="lib-trend-note"><b>${escapeHtml(T("trend_spotlight_heading"))}</b></p></div>`;
    if (spotlight.length) {
      const n = Math.min(3, spotlight.length);
      let spotCls = "lib-trend-spotlight-cols";
      if (n === 1) spotCls += " lib-trend-spotlight-cols--1";
      else if (n === 2) spotCls += " lib-trend-spotlight-cols--2";
      html += `<div class="${spotCls}">`;
      for (let i = 0; i < n; i++) {
        html += `<div class="lib-sl-column">${trendSpotlightCardHtml(spotlight[i], T, escapeHtml, today, langFn)}</div>`;
      }
      html += "</div>";
    } else {
      html += `<p class="lib-trend-caption">${escapeHtml(T("trend_spotlight_empty"))}</p>`;
    }

    if (rest.length) {
      html += `<details class="lib-st-expander"><summary>${escapeHtml(T("trend_by_use_heading"))}</summary><div class="lib-trend-expander-body">`;
      for (const row of rest) {
        html += trendRowHtml(row, T, escapeHtml, today, false, langFn);
      }
      html += "</div></details>";
    } else {
      html += `<p class="lib-trend-caption">${escapeHtml(T("trend_list_empty"))}</p>`;
    }

    if (archivedF.length) {
      html += '<hr class="lib-trend-sep" />';
      html += `<details class="lib-st-expander"><summary>${escapeHtml(T("trend_archive_expander"))}</summary><div class="lib-trend-expander-body">`;
      const byMonth = new Map();
      for (const row of archivedF.slice().sort((a, b) => {
        const pa = String(a.pub_date_iso || "");
        const pb = String(b.pub_date_iso || "");
        if (pa !== pb) return pb.localeCompare(pa);
        return String(b.id || "").localeCompare(String(a.id || ""));
      })) {
        const ym = String(row.pub_date_iso || "").slice(0, 7) || "—";
        if (!byMonth.has(ym)) byMonth.set(ym, []);
        byMonth.get(ym).push(row);
      }
      const yms = Array.from(byMonth.keys()).sort((a, b) => (a < b ? 1 : a > b ? -1 : 0));
      for (const ym of yms) {
        html += `<div class="lib-trend-wrap"><p class="lib-trend-archive-month">${escapeHtml(T("trend_archive_month_prefix"))} ${escapeHtml(ym)}</p></div>`;
        for (const row of byMonth.get(ym)) {
          html += trendRowHtml(row, T, escapeHtml, today, true, langFn);
        }
      }
      html += "</div></details>";
    }

    box.innerHTML = html;
  } catch (dynErr) {
    console.error("[top-page] renderTrendDynamic:", dynErr);
    try {
      const box2 = host && host.querySelector("#lib-trend-dynamic");
      if (box2) {
        box2.innerHTML =
          '<p class="lib-trend-caption">（トレンド表示中にエラー。詳細はコンソール）</p>';
      }
    } catch (innerErr) {
      console.error("[top-page] renderTrendDynamic フォールバック:", innerErr);
    }
  }
}

function trendSpotlightCardHtml(row, T, escapeHtml, today, langFn) {
  const title = langFn() === "en" ? row.title_en || row.title_ja : row.title_ja;
  const summary = row.summary || "";
  const pub = String(row.pub_date_iso || "").slice(0, 10);
  const pubDate = new Date(pub + "T00:00:00");
  const ageDays = Math.floor((today - pubDate) / 86400000);
  const newBadge = ageDays <= 14;
  const tier = String(row.reliability_tier || "");
  const newHtml = newBadge ? '<span class="lib-trend-badge lib-trend-badge--new">NEW</span>' : "";
  const tierHtml = `<span class="${tierBadgeClass(tier)}">${escapeHtml(tier)}</span>`;
  const catHtml = `<span class="lib-trend-badge lib-trend-badge--tier-oth">${escapeHtml(row.category)}</span>`;
  const fixedScore = fmtTrendScore(T("trend_score_caption"), row.display_score);
  const url = String(row.source_url || "");
  let link = "";
  if (url.startsWith("http://") || url.startsWith("https://")) {
    link = `<p class="lib-trend-wrap" style="margin:0.35rem 0 0 0"><a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(T("trend_open_official"))}</a></p>`;
  }
  return `
<div class="lib-trend-wrap lib-trend-card lib-trend-card--spotlight">
  <div class="lib-trend-badges">${newHtml}${tierHtml}${catHtml}</div>
  <p class="lib-trend-card-title">${escapeHtml(title)}</p>
  <p class="lib-trend-card-sum">${escapeHtml(summary)}</p>
  <p class="lib-trend-meta">${escapeHtml(row.source_label != null ? row.source_label : "")} · ${escapeHtml(pub)}</p>
  <p class="lib-trend-score">${escapeHtml(fixedScore)}</p>
</div>
${link}`;
}

function trendRowHtml(row, T, escapeHtml, today, compact, langFn) {
  const title = langFn() === "en" ? row.title_en || row.title_ja : row.title_ja;
  const summary = row.summary || "";
  const pub = String(row.pub_date_iso || "").slice(0, 10);
  const pubDate = new Date(pub + "T00:00:00");
  const ageDays = Math.floor((today - pubDate) / 86400000);
  const newBadge = ageDays <= 14;
  const newHtml = newBadge ? '<span class="lib-trend-badge lib-trend-badge--new">NEW</span> ' : "";
  const tier = String(row.reliability_tier || "");
  const tierBadge = `<span class="${tierBadgeClass(tier)}">${escapeHtml(tier)}</span> `;
  let scoreHtml = "";
  if (!compact) {
    const sc = fmtTrendScore(T("trend_score_caption"), row.display_score);
    scoreHtml = `<p class="lib-trend-score">${escapeHtml(sc)}</p>`;
  }
  const left = `
<div class="lib-trend-wrap">
  <p class="lib-trend-row-title">${newHtml}${escapeHtml(title)}</p>
  <p class="lib-trend-meta">${tierBadge}${escapeHtml(row.source_label != null ? row.source_label : "")} · ${escapeHtml(pub)} · ${escapeHtml(row.category)}</p>
  ${scoreHtml}
</div>`;
  const mid = `<div class="lib-trend-wrap"><p class="lib-trend-card-sum" style="margin:0">${escapeHtml(summary)}</p></div>`;
  const url = String(row.source_url || "");
  let link = "";
  if (url.startsWith("http://") || url.startsWith("https://")) {
    link = `<p class="lib-trend-wrap" style="margin:0.35rem 0 0 0"><a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(T("trend_open_official"))}</a></p>`;
  }
  return `<div class="lib-trend-row">${left}<div>${mid}</div><div></div></div>${link}`;
}

function defaultTopApiUrl(path) {
  const p = String(path || "");
  if (p.startsWith("http://") || p.startsWith("https://")) return p;
  return p.startsWith("/") ? p : "/" + p;
}

function defaultTopEscapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function defaultTopLang() {
  return R.readSession(R.LANG_KEY, "ja") === "en" ? "en" : "ja";
}

function defaultTopT(key) {
  return key;
}

async function defaultTopFetchJson(path, opts) {
  try {
    const r = await fetch(defaultTopApiUrl(path), opts);
    if (!r.ok) throw new Error(path + " " + r.status);
    const text = await r.text();
    return JSON.parse(text);
  } catch (e) {
    console.error("API取得失敗:", path, e);
    if (path.indexOf("top-news") >= 0) return { items: [], logo: null };
    if (path.indexOf("trend-items") >= 0) return { items: [], source_key_to_group: {} };
    return {};
  }
}

function resolveTopDeps(deps) {
  console.log("deps確認:", deps);
  const d = deps || {};
  const out = {};
  if (typeof d.apiUrl === "function") {
    out.apiUrl = d.apiUrl;
  } else {
    console.warn("deps不足: apiUrl");
    out.apiUrl = defaultTopApiUrl;
  }
  if (typeof d.fetchJson === "function") {
    out.fetchJson = d.fetchJson;
  } else {
    console.warn("deps不足: fetchJson");
    out.fetchJson = defaultTopFetchJson;
  }
  if (typeof d.escapeHtml === "function") {
    out.escapeHtml = d.escapeHtml;
  } else {
    console.warn("deps不足: escapeHtml");
    out.escapeHtml = defaultTopEscapeHtml;
  }
  if (typeof d.T === "function") {
    out.T = d.T;
  } else {
    console.warn("deps不足: T");
    out.T = defaultTopT;
  }
  if (typeof d.lang === "function") {
    out.lang = d.lang;
  } else {
    console.warn("deps不足: lang");
    out.lang = defaultTopLang;
  }
  return out;
}

function appendHtmlNodes(parent, html) {
  const w = document.createElement("div");
  w.innerHTML = html;
  while (w.firstChild) parent.appendChild(w.firstChild);
}

/** @param lang {() => string} */
export async function renderTopPage(host, deps) {
  console.log("TOP開始");
  if (!host) {
    console.error("page-hostが存在しない");
    return;
  }

  const { apiUrl, fetchJson, escapeHtml, T, lang } = resolveTopDeps(deps);

  try {
    host.classList.add("page-top");
    host.innerHTML = "";

    const root = document.createElement("div");
    root.className = "lib-top-page-inner";
    root.innerHTML = `
<div class="lib-top-smoke-test" style="padding:0.75rem 1rem;background:#f1f5f9;border-bottom:1px solid #cbd5e1">
  <h1 style="margin:0;font-size:1.1rem;color:#0f172a">TOP描画テスト</h1>
</div>`;
    host.appendChild(root);

    let newsRes;
    try {
      const L0 = lang();
      newsRes = await fetchJson("/api/top-news?lang=" + encodeURIComponent(L0) + "&load_cap=80");
    } catch (e) {
      console.error("ニュース取得失敗:", e);
      newsRes = { items: [], logo: null };
    }

    let trendRes;
    try {
      const L1 = lang();
      trendRes = await fetchJson("/api/trend-items?lang=" + encodeURIComponent(L1));
    } catch (e) {
      console.error("トレンド取得失敗:", e);
      trendRes = { items: [], source_key_to_group: {} };
    }

    const newsData = Array.isArray(newsRes) ? { items: newsRes, logo: null } : newsRes;
    const newsItems = newsData.items || [];
    const trendItems = trendRes.items || [];
    const srcMap = trendRes.source_key_to_group || {};

    try {
      injectTopNavCardCss(apiUrl);
    } catch (cssErr) {
      console.error("[top-page] topnav CSS 注入エラー:", cssErr);
    }

    root.innerHTML = "";

    const L = lang();
    const _hl = L === "en" ? "en" : "ja";
    const subLines = T("hero_sub")
      .split("\n")
      .filter((x) => x.trim())
      .map((x) => escapeHtml(x.trim()))
      .join("<br><br>");

    let logoImgHtml = "";
    if (newsData.logo && newsData.logo.src) {
      const alt = escapeHtml(newsData.logo.alt || "");
      logoImgHtml = `<img src="${escapeHtml(newsData.logo.src)}" alt="${alt}" style="max-width:240px;width:100%;height:auto;display:block;object-fit:contain;" />`;
    }

    const featLbl = T("news_featured_label");
    const moreTpl = T("news_more_expander_tpl");
    const archLbl = T("news_archive_expander");
    const monthPfx = T("news_archive_month_prefix");
    const linkLbl = T("news_link_label");
    const emptyHint = T("news_empty_hint");
    const [featured, current, archive] = splitCurrentArchiveNews(newsItems, true, 3);

    let newsRightHtml = `<p style="font-size:0.82rem;font-weight:700;color:#475569;margin:0 0 0.55rem 0;">${escapeHtml(featLbl)}</p>`;
    if (featured) {
      newsRightHtml += '<div id="lib-tzk-news-anchor" style="height:0;margin:0;" aria-hidden="true"></div>';
      newsRightHtml += buildNewsCardHtml(featured, true, logoImgHtml, linkLbl, escapeHtml);
    } else {
      newsRightHtml += `<p class="lib-news-empty-caption">${escapeHtml(emptyHint)}</p>`;
    }
    if (current.length) {
      const expLabel = moreTpl.replace("{n}", String(current.length));
      newsRightHtml += `<details class="lib-st-expander"><summary>${escapeHtml(expLabel)}</summary><div class="lib-news-stack">`;
      for (const row of current) {
        newsRightHtml += buildNewsCardHtml(row, false, logoImgHtml, linkLbl, escapeHtml);
      }
      newsRightHtml += "</div></details>";
    }
    if (archive.length) {
      newsRightHtml += `<details class="lib-st-expander"><summary>${escapeHtml(archLbl)}</summary>`;
      newsRightHtml += buildNewsArchiveHtml(archive, monthPfx, logoImgHtml, linkLbl, escapeHtml);
      newsRightHtml += "</details>";
    }

    const lede = T("news_section_lede").trim()
      ? `<p class="lib-tzk-news-lede">${escapeHtml(T("news_section_lede"))}</p>`
      : "";

    let navHtml = "";
    for (let gi = 0; gi < TOP_NAV_GROUPS.length; gi++) {
      const pages = TOP_NAV_GROUPS[gi];
      const n = pages.length;
      const colsPer = Math.min(5, Math.max(1, n));
      navHtml += `<div class="lib-topnav-group-rows" data-group-idx="${gi}">`;
      navHtml += `<div class="lib-sl-columns lib-sl-columns-${colsPer} lib-sl-gap-medium">`;
      for (let j = 0; j < colsPer; j++) {
        navHtml += '<div class="lib-sl-column">';
        if (j < n) {
          const page = pages[j];
          const spec = TOP_NAV_CARD_SPECS.find((s) => s.page === page);
          if (!spec) {
            console.error("[top-page] missing TOP_NAV_CARD_SPEC for page:", page);
            navHtml += `<p class="lib-news-empty-caption">設定エラー: 「${escapeHtml(String(page))}」</p>`;
          } else {
            const cur = R.getHashPage();
            const onPage = page === cur;
            const cid = spec.cardId;
            const wk = topnavStreamlitKey(cid);
            if (onPage) {
              navHtml += `<div class="lib-ai-nav-onpage" data-lib-topnav-id="${escapeHtml(cid)}"><p>表示中：${escapeHtml(cardTitle(page, T, lang))}</p></div>`;
            } else {
              navHtml += `<div class="st-key-${wk}" data-testid="stButton"><button type="button" data-testid="baseButton-primary" kind="primary" data-nav-target="${escapeHtml(page)}">${escapeHtml(cardTitle(page, T, lang))}</button></div>`;
            }
          }
        }
        navHtml += "</div>";
      }
      navHtml += "</div>";
      if (gi < TOP_NAV_GROUPS.length - 1) {
        navHtml += '<div class="lib-topnav-after-group-spacer" aria-hidden="true"></div>';
      }
    }

    const trendSectionTitle = `
<div class="lib-corp-sec">
  <h3 class="lib-corp-sec-jp">${escapeHtml(T("trend_section_title"))}</h3>
  <div class="lib-corp-sec-line" aria-hidden="true"></div>
</div>`;

    const trendFilters = `
<div class="lib-trend-filters-row lib-sl-columns-2 lib-sl-gap-default">
  <div class="lib-sl-column">
    <label class="lib-st-widget-label" for="lib_trend_filter_category">${escapeHtml(T("trend_filter_category"))}</label>
    <select id="lib_trend_filter_category" class="lib-st-select">
      <option>${escapeHtml(T("trend_cat_all"))}</option>
      <option>住宅</option><option>オフィス</option><option>商業</option><option>J-REIT</option>
    </select>
  </div>
  <div class="lib-sl-column">
    <label class="lib-st-widget-label" for="lib_trend_filter_source">${escapeHtml(T("trend_filter_source"))}</label>
    <select id="lib_trend_filter_source" class="lib-st-select">
      <option>${escapeHtml(T("trend_src_all"))}</option>
      <option>${escapeHtml(T("trend_src_kokudo"))}</option>
      <option>${escapeHtml(T("trend_src_sanki"))}</option>
      <option>${escapeHtml(T("trend_src_reit"))}</option>
      <option>${escapeHtml(T("trend_src_other"))}</option>
    </select>
  </div>
</div>`;

    const heroBlockHtml = `
  <div class="hero-visual hero-visual--fullvp" lang="${escapeHtml(_hl)}" style="--lib-hero-photo:url('${escapeHtml(apiUrl("/api/system-asset/" + encAssetRel("image/ai_realestate_bg.jpg")))}');">
    <div class="hero-visual__bg" aria-hidden="true"></div>
    <div class="hero-inner">
      <div class="hero-copy hero-copy-panel">
        <p class="hero-tagline-jp">${escapeHtml(T("hero_kicker"))}</p>
        <p class="hero-micro-en" lang="en">Price is structure</p>
        <div class="headline">${escapeHtml(T("hero_headline"))}</div>
        <div class="gold-line" aria-hidden="true"></div>
        <div class="subcopy">
${subLines}<br><br>
        </div>
        <p class="hero-footnote">${escapeHtml(T("hero_foot"))}</p>
      </div>
    </div>
  </div>
  <div class="lib-sl-columns lib-sl-columns-2 lib-sl-gap-small lib-top-hero-cta-row">
    <div class="lib-sl-column" data-testid="column">
      <div data-testid="stButton"><button type="button" data-testid="baseButton-primary" kind="primary" data-nav-target="業務内容">${escapeHtml(T("top_cta_services"))}</button></div>
    </div>
    <div class="lib-sl-column" data-testid="column">
      <div data-testid="stButton"><button type="button" data-testid="baseButton-secondary" kind="secondary" data-nav-target="AI分析ツール">${escapeHtml(T("top_cta_ai"))}</button></div>
    </div>
  </div>
  <div class="hr" role="separator" aria-hidden="true"></div>`;
    console.log("ヒーロー描画開始");
    const heroFrag = document.createDocumentFragment();
    appendHtmlNodes(heroFrag, heroBlockHtml);
    root.appendChild(heroFrag);

    const newsBlockHtml = `
  <section class="lib-top-news-split">
    <div class="lib-tzk-news-columns lib-sl-gap-large">
      <div class="lib-tzk-news-left">
        <div class="lib-tzk-news-edu lib-tzk-news-wide">
          <p class="lib-tzk-news-kicker">${escapeHtml(T("news_section_kicker"))}</p>
          <h2 class="lib-tzk-news-mast">${escapeHtml(T("news_section_mast"))}</h2>
          ${lede}
          <div class="lib-tzk-news-accent-bar" aria-hidden="true"></div>
        </div>
      </div>
      <div class="lib-tzk-news-right">
        ${newsRightHtml}
      </div>
    </div>
  </section>
  <div class="hr" role="separator" aria-hidden="true"></div>`;
    console.log("ニュース描画開始");
    const newsFrag = document.createDocumentFragment();
    appendHtmlNodes(newsFrag, newsBlockHtml);
    root.appendChild(newsFrag);

    const trendBlockHtml = `
  <section class="lib-top-trends">
    ${trendSectionTitle}
    <details class="lib-st-expander"><summary>${escapeHtml(T("trend_notes_expander"))}</summary>
      <div class="lib-trend-notes-md">${liteBoldHtml(T("trend_section_sub"), escapeHtml)}</div>
      <div class="lib-trend-notes-md">${liteBoldHtml(T("trend_legal_note"), escapeHtml)}</div>
    </details>
    ${trendFilters}
    <div id="lib-trend-dynamic" class="lib-trend-dynamic"></div>
  </section>
  <div class="hr" role="separator" aria-hidden="true"></div>`;
    console.log("トレンド描画開始");
    const trendFrag = document.createDocumentFragment();
    appendHtmlNodes(trendFrag, trendBlockHtml);
    root.appendChild(trendFrag);

    const navBlockHtml = `  <section class="lib-top-nav-groups">${navHtml}</section>
  <div class="hr" role="separator" aria-hidden="true"></div>`;
    console.log("ナビ描画開始");
    const navFrag = document.createDocumentFragment();
    appendHtmlNodes(navFrag, navBlockHtml);
    root.appendChild(navFrag);

    try {
      host.dataset.trendSrcMap = JSON.stringify(srcMap || {});
    } catch (e) {
      console.error("JSON stringify失敗:", e);
      host.dataset.trendSrcMap = "{}";
    }

    bindNav(host, ".lib-top-hero-cta-row button[data-nav-target]");
    bindNav(host, '.lib-top-nav-groups button[data-nav-target]');

    const catSel = host.querySelector("#lib_trend_filter_category");
    const srcSel = host.querySelector("#lib_trend_filter_source");
    const rerender = () => {
      try {
        renderTrendDynamic(host, trendItems, T, escapeHtml, lang);
      } catch (re) {
        console.error("[top-page] トレンド再描画:", re);
      }
    };
    if (catSel) catSel.addEventListener("change", rerender);
    if (srcSel) srcSel.addEventListener("change", rerender);
    try {
      rerender();
    } catch (firstTrendErr) {
      console.error("[top-page] トレンド初回描画:", firstTrendErr);
    }
    console.log("TOP完全描画完了");
  } catch (topErr) {
    console.error("致命エラー:", topErr);
    const msg = String(topErr && topErr.stack ? topErr.stack : topErr);
    const esc = typeof escapeHtml === "function" ? escapeHtml : defaultTopEscapeHtml;
    try {
      host.innerHTML = "<h1>描画エラー</h1><pre>" + esc(msg) + "</pre>";
    } catch (eHost) {
      console.error(eHost);
      try {
        document.body.innerHTML = "<h1>描画エラー</h1><pre>" + esc(msg) + "</pre>";
      } catch (eBody) {
        console.error(eBody);
      }
    }
  }
}
