# Netlify 向けデプロイ手順

## この ZIP に含めるもの（ルート＝サイトの公開ルート）

```
index.html
style.css
_redirects
js/
  app.js
  ui-render.js
  router.js
```

**`_redirects` は必須です。** 無いと `/mekiki` などのパス URL が 404 のままになります。

## Netlify の設定

リポジトリルートが **`system New/`** の場合、ルートの **`netlify.toml`** で `publish = "frontend"` を指定済みです（ダッシュボードの Publish directory と同じ意味）。

1. **Publish directory**（またはドラッグ＆ドロップするフォルダ）を、**必ずこの `frontend` フォルダ自身**にする。  
   - リポジトリ全体を publish にすると、`index.html` は `https://ドメイン/` にあるのに、`./js/app.js` は `https://ドメイン/js/app.js` を指し、実ファイルが `https://ドメイン/frontend/js/...` にしか無い → **JS が 404 で HTML が返り `SyntaxError`** になります。
2. Build command は不要（静的ファイルのみ）なら空でよいです。
3. デプロイ後、ブラウザで `https://（あなたのドメイン）/js/app.js` を開き、**先頭が `/**` や `import` などの JavaScript** であることを確認してください（`<!DOCTYPE` ならまだパス／publish のミスです）。

## `_redirects` の意味

```
/* /index.html 200
```

すべてのパスを `index.html` に返し、**クライアント側のハッシュルータ**（`#/mekiki` 等）が動くようにします。
