/**
 * /api/ui/* の JSON（title + sections）から DOM を組み立てる。
 */
import * as R from "./router.js";

const DEFAULT_TIMEOUT_MS = 18000;

export function showLoading(host) {
  host.innerHTML =
    '<div class="ui-loading" role="status"><div class="ui-loading__spinner" aria-hidden="true"></div><p class="ui-loading__text">Loading…</p></div>';
}

export function showFetchError(host, title, err, timeoutMs) {
  const msg = String(err && err.message ? err.message : err);
  const hint = timeoutMs ? `<p class="ui-error__hint">Timeout: ${timeoutMs}ms</p>` : "";
  host.innerHTML =
    '<div class="ui-error">' +
    "<h1>" +
    escapeHtmlStatic(title) +
    "</h1><pre>" +
    escapeHtmlStatic(msg) +
    "</pre>" +
    hint +
    "</div>";
}

function escapeHtmlStatic(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function fetchWithTimeout(url, options, timeoutMs) {
  const ctrl = new AbortController();
  const id = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { ...options, signal: ctrl.signal });
    return r;
  } finally {
    clearTimeout(id);
  }
}

export async function fetchUiJson(apiUrl, segment, lang, timeoutMs) {
  const ms = timeoutMs || DEFAULT_TIMEOUT_MS;
  const q = "?lang=" + encodeURIComponent(lang);
  const url = apiUrl("/api/ui/" + segment + q);
  const r = await fetchWithTimeout(url, { method: "GET", headers: { Accept: "application/json" } }, ms);
  if (!r.ok) throw new Error(url + " → " + r.status);
  return JSON.parse(await r.text());
}

function renderHero(sec, escapeHtml, liteBoldHtml) {
  const m = sec.meta || {};
  const logo = m.logo;
  let logoHtml = "";
  if (logo && logo.src) {
    logoHtml =
      '<div class="ui-hero__logo"><img src="' +
      escapeHtml(logo.src) +
      '" alt="' +
      escapeHtml(logo.alt || "") +
      '" /></div>';
  }
  const ctas = (m.ctas || [])
    .map((c) => {
      const v = c.variant === "secondary" ? "ui-cta ui-cta--secondary" : "ui-cta ui-cta--primary";
      return (
        '<button type="button" class="' +
        v +
        '" data-nav-target="' +
        escapeHtml(c.navTarget || "") +
        '">' +
        escapeHtml(c.label || "") +
        "</button>"
      );
    })
    .join("");
  return (
    '<section class="ui-hero">' +
    logoHtml +
    '<div class="ui-hero__copy">' +
    '<p class="ui-hero__kicker">' +
    escapeHtml(m.kicker || "") +
    "</p>" +
    '<p class="ui-hero__micro" lang="en">' +
    escapeHtml(m.micro_en || "") +
    "</p>" +
    '<h1 class="ui-hero__headline">' +
    escapeHtml(m.headline || "") +
    "</h1>" +
    '<div class="ui-hero__sub">' +
    liteBoldHtml(m.subcopy || "") +
    "</div>" +
    '<p class="ui-hero__foot">' +
    escapeHtml(m.footnote || "") +
    "</p>" +
    '<div class="ui-hero__ctas">' +
    ctas +
    "</div></div></section>"
  );
}

function renderCards(sec, escapeHtml, liteBoldHtml) {
  const layout = (sec.meta && sec.meta.layout) || "default";
  const title = sec.title ? "<h2 class=\"ui-sec-title\">" + escapeHtml(sec.title) + "</h2>" : "";
  const lead = sec.text ? "<p class=\"ui-sec-lead\">" + liteBoldHtml(sec.text) + "</p>" : "";
  const kicker = sec.meta && sec.meta.kicker ? "<p class=\"ui-sec-kicker\">" + escapeHtml(sec.meta.kicker) + "</p>" : "";
  const items = sec.items || [];
  let body = "";
  if (layout === "nav") {
    body =
      '<div class="ui-card-grid ui-card-grid--nav">' +
      items
        .map(
          (it) =>
            '<article class="ui-card ui-card--nav" data-nav-target="' +
            escapeHtml(it.navTarget || "") +
            '"><h3>' +
            escapeHtml(it.title || "") +
            "</h3><p>" +
            escapeHtml(it.text || "") +
            "</p></article>",
        )
        .join("") +
      "</div>";
  } else {
    body =
      '<div class="ui-card-grid">' +
      items
        .map((it) => {
          const mh = it.meta && it.meta.body_html ? '<div class="ui-card__bodymd">' + it.meta.body_html + "</div>" : "";
          const sub = it.subtitle ? '<p class="ui-card__sub">' + escapeHtml(it.subtitle) + "</p>" : "";
          return (
            '<article class="ui-card"><h3>' +
            escapeHtml(it.title || "") +
            "</h3>" +
            sub +
            "<p>" +
            liteBoldHtml(it.text || "") +
            "</p>" +
            mh +
            "</article>"
          );
        })
        .join("") +
      "</div>";
  }
  return '<section class="ui-sec ui-sec--cards">' + kicker + title + lead + body + "</section>";
}

function renderTable(sec, escapeHtml, liteBoldHtml) {
  const cols = (sec.meta && sec.meta.columns) || [
    { key: "title", label: "Title" },
    { key: "text", label: "Detail" },
  ];
  const items = sec.items || [];
  const head = "<tr>" + cols.map((c) => "<th>" + escapeHtml(c.label) + "</th>").join("") + "</tr>";
  const rows = items
    .map((it) => {
      return (
        "<tr>" +
        cols
          .map((c) => {
            const v = it[c.key] != null ? String(it[c.key]) : "";
            return "<td>" + (c.key === "text" ? liteBoldHtml(v) : escapeHtml(v)) + "</td>";
          })
          .join("") +
        "</tr>"
      );
    })
    .join("");
  const title = sec.title ? "<h2 class=\"ui-sec-title\">" + escapeHtml(sec.title) + "</h2>" : "";
  const note = sec.text ? "<p class=\"ui-sec-lead\">" + liteBoldHtml(sec.text) + "</p>" : "";
  return (
    '<section class="ui-sec ui-sec--table">' + title + note + '<div class="ui-table-wrap"><table class="ui-table"><thead>' + head + "</thead><tbody>" + rows + "</tbody></table></div></section>"
  );
}

function renderChart(sec, escapeHtml) {
  const m = sec.meta || {};
  const items = sec.items || [];
  const yk = m.yKey || "pv_million";
  const xk = m.xKey || "year";
  const maxY = Math.max(1, ...items.map((r) => Number(r[yk]) || 0));
  const bars = items
    .map((r) => {
      const h = Math.round(((Number(r[yk]) || 0) / maxY) * 100);
      return (
        '<div class="ui-chart__barwrap"><div class="ui-chart__bar" style="height:' +
        h +
        '%"></div><span class="ui-chart__x">' +
        escapeHtml(String(r[xk] ?? "")) +
        "</span></div>"
      );
    })
    .join("");
  const title = sec.title ? "<h2 class=\"ui-sec-title\">" + escapeHtml(sec.title) + "</h2>" : "";
  const cap = sec.text ? "<p class=\"ui-sec-lead\">" + escapeHtml(sec.text) + "</p>" : "";
  return '<section class="ui-sec ui-sec--chart">' + title + cap + '<div class="ui-chart">' + bars + "</div></section>";
}

function renderText(sec, escapeHtml, liteBoldHtml) {
  const m = sec.meta || {};
  const id = m.id ? ' id="' + escapeHtml(m.id) + '"' : "";
  const title = sec.title ? "<h2 class=\"ui-sec-title\">" + escapeHtml(sec.title) + "</h2>" : "";
  const body = sec.text ? "<div class=\"ui-sec-md\"" + id + ">" + liteBoldHtml(sec.text) + "</div>" : "<div" + id + "></div>";
  return '<section class="ui-sec ui-sec--text">' + title + body + "</section>";
}

function fieldHtml(f, escapeHtml) {
  const nm = escapeHtml(f.name || "");
  const lab = escapeHtml(f.label || "");
  const ph = escapeHtml(f.placeholder || "");
  const typ = f.input || "text";
  if (typ === "hidden") {
    return '<input type="hidden" name="' + nm + '" value="' + escapeHtml(String(f.value ?? "")) + '" />';
  }
  if (typ === "textarea") {
    return (
      '<label class="ui-field"><span class="ui-field__l">' +
      lab +
      '</span><textarea name="' +
      nm +
      '" placeholder="' +
      ph +
      '">' +
      escapeHtml(String(f.value ?? "")) +
      "</textarea></label>"
    );
  }
  if (typ === "checkbox") {
    const ch = f.value ? " checked" : "";
    return (
      '<label class="ui-field ui-field--inline"><input type="checkbox" name="' +
      nm +
      '"' +
      ch +
      ' /><span>' +
      lab +
      "</span></label>"
    );
  }
  if (typ === "select") {
    const opts = (f.options || [])
      .map((o) => {
        const sel = String(o) === String(f.value) ? " selected" : "";
        return "<option" + sel + ">" + escapeHtml(String(o)) + "</option>";
      })
      .join("");
    return '<label class="ui-field"><span class="ui-field__l">' + lab + '</span><select name="' + nm + '">' + opts + "</select></label>";
  }
  const step = f.step ? ' step="' + escapeHtml(f.step) + '"' : "";
  return (
    '<label class="ui-field"><span class="ui-field__l">' +
    lab +
    '</span><input type="' +
    escapeHtml(typ) +
    '" name="' +
    nm +
    '" value="' +
    escapeHtml(String(f.value ?? "")) +
    '"' +
    step +
    ' placeholder="' +
    ph +
    '" /></label>'
  );
}

function renderForm(sec, escapeHtml, deps) {
  const m = sec.meta || {};
  const fields = (sec.items || []).map((f) => fieldHtml(f, escapeHtml)).join("");
  const title = sec.title ? "<h2 class=\"ui-sec-title\">" + escapeHtml(sec.title) + "</h2>" : "";
  const intro = sec.text ? "<p class=\"ui-sec-lead\">" + deps.liteBoldHtml(sec.text) + "</p>" : "";
  let buttons = "";
  if (m.renderer === "mekiki" && Array.isArray(m.buttons)) {
    buttons = m.buttons
      .map((b) => {
        const primary = b.id === "run" ? " ui-cta--primary" : " ui-cta--secondary";
        return (
          '<button type="button" class="ui-cta' +
          primary +
          '" data-mekiki-act="' +
          escapeHtml(b.id) +
          '">' +
          escapeHtml(b.label) +
          "</button>"
        );
      })
      .join("");
  } else if (m.action === "dcf-recalc") {
    buttons = '<button type="button" class="ui-cta ui-cta--primary" data-dcf-recalc="1">' + escapeHtml(m.submitLabel || "OK") + "</button>";
  } else if (m.action === "mailto") {
    buttons = '<button type="button" class="ui-cta ui-cta--primary" data-mailto-send="1">' + escapeHtml(m.submitLabel || "OK") + "</button>";
  }
  return (
    '<section class="ui-sec ui-sec--form" data-ui-form="' +
    escapeHtml(m.renderer || m.action || "generic") +
    '">' +
    title +
    intro +
    '<form class="ui-form" onsubmit="return false">' +
    fields +
    '<div class="ui-form__actions">' +
    buttons +
    "</div></form></section>"
  );
}

export function renderUIPage(host, data, deps) {
  const { escapeHtml, liteBoldHtml } = deps;
  const title = data.title || "";
  const sections = data.sections || [];
  const parts = ['<div class="ui-page">', "<header class=\"ui-page__head\"><h1 class=\"page-title\">" + escapeHtml(title) + "</h1></header>"];
  for (const sec of sections) {
    const t = sec.type;
    if (t === "hero") parts.push(renderHero(sec, escapeHtml, liteBoldHtml));
    else if (t === "cards") parts.push(renderCards(sec, escapeHtml, liteBoldHtml));
    else if (t === "table") parts.push(renderTable(sec, escapeHtml, liteBoldHtml));
    else if (t === "chart") parts.push(renderChart(sec, escapeHtml));
    else if (t === "text") parts.push(renderText(sec, escapeHtml, liteBoldHtml));
    else if (t === "form") parts.push(renderForm(sec, escapeHtml, deps));
    else parts.push("<section class=\"ui-sec\"><p>" + escapeHtml("Unknown section: " + t) + "</p></section>");
  }
  parts.push("</div>");
  host.innerHTML = parts.join("");
  wireUiInteractions(host, deps);
}

function wireUiInteractions(host, deps) {
  const { apiUrl, lang, escapeHtml } = deps;
  host.querySelectorAll("[data-nav-target]").forEach((el) => {
    el.addEventListener("click", () => {
      const p = el.getAttribute("data-nav-target");
      if (p) R.setHashPage(p);
    });
  });
  host.querySelectorAll(".ui-card--nav").forEach((card) => {
    card.addEventListener("click", () => {
      const p = card.getAttribute("data-nav-target");
      if (p) R.setHashPage(p);
    });
  });
  host.querySelectorAll("[data-mekiki-act]").forEach((btn) => {
    btn.addEventListener("click", () => void handleMekikiAct(btn.getAttribute("data-mekiki-act"), host, deps));
  });
  host.querySelectorAll("[data-dcf-recalc]").forEach((btn) => {
    btn.addEventListener("click", () => void handleDcfRecalc(host, deps));
  });
  host.querySelectorAll("[data-mailto-send]").forEach((btn) => {
    btn.addEventListener("click", () => handleMailto(host, deps));
  });
}

async function handleMekikiAct(act, host, deps) {
  const form = host.querySelector('section[data-ui-form="mekiki"] form') || host.querySelector(".ui-form");
  if (!form) return;
  const raw = (form.querySelector('[name="raw_listing"]') || {}).value || "";
  const L = deps.lang();
  if (act === "parse") {
    try {
      const r = await fetchWithTimeout(
        deps.apiUrl("/parse_listing"),
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ raw_listing: raw, lang: L }),
        },
        DEFAULT_TIMEOUT_MS,
      );
      const data = await r.json();
      const p = data.parsed || {};
      const set = (n, v) => {
        const el = form.querySelector('[name="' + n + '"]');
        if (el && v != null && v !== "") el.value = v;
      };
      set("price_myen", p.price_myen);
      set("area_sqm", p.area_sqm);
      set("walk_min", p.walk_min);
      const bc = form.querySelector('[name="building_condition"]');
      if (bc) bc.checked = !!p.building_condition;
      set("address", p.address);
    } catch (e) {
      console.error(e);
      alert(String(e.message || e));
    }
    return;
  }
  if (act !== "run") return;

  const body = {
    lang: ((form.querySelector('[name="lang"]') || {}).value || L),
    raw_listing: raw,
    price_myen: Number((form.querySelector('[name="price_myen"]') || {}).value || 0),
    area_sqm: Number((form.querySelector('[name="area_sqm"]') || {}).value || 0),
    walk_min: Number((form.querySelector('[name="walk_min"]') || {}).value || 0),
    building_condition: !!(form.querySelector('[name="building_condition"]') || {}).checked,
    address: (form.querySelector('[name="address"]') || {}).value || "",
    region: (form.querySelector('[name="region"]') || {}).value || "全国（暫定）",
    road_width_m: Number((form.querySelector('[name="road_width_m"]') || {}).value || 0),
    shape_risk: (form.querySelector('[name="shape_risk"]') || {}).value || "不明",
    comps_raw: (form.querySelector('[name="comps_raw"]') || {}).value || "",
  };
  const out = host.querySelector("#mekiki-result-host");
  if (out) out.innerHTML = "<p>…</p>";
  try {
    const r = await fetchWithTimeout(
      deps.apiUrl("/api/price"),
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) },
      DEFAULT_TIMEOUT_MS,
    );
    const res = await r.json();
    if (res.error) {
      if (out) out.innerHTML = "<pre class=\"ui-mekiki-err\">" + escapeHtml(res.error) + "</pre>";
      return;
    }
    let html = "";
    if (res.summary_text) html += "<div class=\"lib-page-md\">" + deps.liteBoldHtml(res.summary_text) + "</div>";
    if (res.detail_lines && res.detail_lines.length) {
      html += "<h3>Detail</h3><ul>";
      for (const line of res.detail_lines) html += "<li>" + deps.liteBoldHtml(line) + "</li>";
      html += "</ul>";
    }
    if (res.table_text) html += "<pre class=\"ui-mekiki-table\">" + escapeHtml(res.table_text) + "</pre>";
    if (res.disclaimer_markdown) html += "<div class=\"lib-page-md\">" + deps.liteBoldHtml(res.disclaimer_markdown) + "</div>";
    if (out) out.innerHTML = html || "<p>(no output)</p>";
  } catch (e) {
    console.error(e);
    if (out) out.innerHTML = "<pre class=\"ui-mekiki-err\">" + escapeHtml(String(e.message || e)) + "</pre>";
  }
}

async function handleDcfRecalc(host, deps) {
  const form = host.querySelector('section[data-ui-form="dcf-recalc"] form') || host.querySelector(".ui-sec--form .ui-form");
  if (!form) return;
  const q = new URLSearchParams();
  q.set("lang", deps.lang());
  q.set("noi_million", String((form.querySelector('[name="noi_million"]') || {}).value || "10"));
  q.set("growth_pct", String((form.querySelector('[name="growth_pct"]') || {}).value || "1"));
  q.set("discount_pct", String((form.querySelector('[name="discount_pct"]') || {}).value || "6"));
  q.set("horizon_years", String((form.querySelector('[name="horizon_years"]') || {}).value || "10"));
  try {
    const u = deps.apiUrl("/api/ui/dcf?" + q.toString());
    const r = await fetchWithTimeout(u, { method: "GET" }, DEFAULT_TIMEOUT_MS);
    const page = await r.json();
    renderUIPage(host, page, deps);
  } catch (e) {
    console.error(e);
    alert(String(e.message || e));
  }
}

function handleMailto(host, deps) {
  const form = host.querySelector(".ui-sec--form .ui-form");
  if (!form) return;
  const purpose = (form.querySelector('[name="purpose"]') || {}).value || "";
  const body = (form.querySelector('[name="body"]') || {}).value || "";
  const root = host.querySelector(".ui-page");
  const em = (root && root.getAttribute("data-office-email")) || "";
  if (!em) {
    alert(deps.T("contact_info_secrets_setup"));
    return;
  }
  const subj = encodeURIComponent("[Contact] " + purpose);
  const b = encodeURIComponent(body);
  window.location.href = "mailto:" + em + "?subject=" + subj + "&body=" + b;
}

/** メールアドレスを .ui-page に付与（contact UI 用） */
export function patchOfficeEmail(host, email) {
  const r = host.querySelector(".ui-page");
  if (r && email) r.setAttribute("data-office-email", email);
}
