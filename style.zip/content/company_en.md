**Company name:** Libralys (ライブラリーズ)

**Representative:** Takamitsu Isoo

**Location:** Suita City, Osaka Prefecture, Japan

**Business:** Real Estate Consulting (valuation support, compensation, litigation support, corporate asset valuation, **Income Analysis**, etc.)

**Established:** April 2026

*Note: Libralys is not currently registered as a designated real estate appraisal firm under the Japanese Real Estate Appraisal Act. Registration is planned for the future.*
