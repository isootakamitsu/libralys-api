## Services (overview)

Libralys provides **Real Estate Consulting** centered on **Real Estate Appraisal** thinking, **Property Price Analysis**, **Income Analysis**, and **Market Analysis**—for transactions, collateral, inheritance, leasing disputes, redevelopment, and corporate decision-making.

*Libralys is not currently registered to provide statutory appraisal services under the Japanese Real Estate Appraisal Act.*

### Reference for purchase and sale (valuation context)

Support for documenting how value is formed and explained to third parties (e.g., lenders, courts, auditors). Emphasis is placed on **Sales Comparison Approach**, **Income Capitalization Approach**, and **Cost Approach** logic, with explicit assumptions.

### Inheritance and gift valuation

Clarify as-of date, **Highest and Best Use**, and legal interests; present scenarios where needed to support family agreements and professional advisors.

### Compensation valuation

Structure loss compensation issues with clear eligibility, assumptions, and reconciliation to market evidence and applicable guidelines.

### Rent disputes and litigation support (rent opinions)

Organize issues for **Property Price Opinion** work in rent-review contexts, using multiple cross-checked methods where appropriate.

### Corporate asset valuation

Purpose-driven analyses for financial reporting, M&A, and internal governance—linking **Discounted Cash Flow (DCF) Analysis** and market evidence where relevant.

### Securitization and income-producing property

DCF-centered narratives with transparent **Capitalization Rate** / **Discount Rate** assumptions and stress views for investors, asset managers, and lenders.

### Ground rent, leasehold premia, and eviction-related settlements

Market-grounded opinions on rent levels, key money, and relocation/eviction compensation frameworks—structured for negotiation and dispute prevention.

---

For the full Japanese service sheets (including detailed technical narratives), open **“Original Japanese service descriptions”** on the Services page when the site is in English.
