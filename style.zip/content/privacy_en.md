## 1. Contribution to the SDGs

As a consulting practice built on expertise and accountability, Libralys recognizes sustainable development as a material responsibility.

**Focus areas (examples)**

- Respect for diversity and inclusion  
- Healthy and safe workplaces  
- Efficient use of energy and office resources  
- ESG-aware real estate analysis where relevant  
- Support for transparent public valuation processes  

These commitments are reflected in day-to-day operations—not only in statements.

---

## 2. Disclosures under the Act on the Protection of Personal Information (Japan)

### (1) Purposes of use

Personal information is used only for:
- Providing real estate consulting services  
- Property research and analysis  
- Responding to inquiries and routine communications  
- Contract administration and billing  

No use beyond these purposes.

### (2) Third-party provision

Except as required by law, personal information is not provided to third parties without consent.  
Opt-out third-party sharing is not used at this time.

### (3) Joint use

Where joint use is necessary for legitimate consulting operations (e.g., market evidence handling), scope, purposes, parties, and the responsible administrator are managed in accordance with applicable law.

### (4) Security measures

Libralys implements technical and organizational safeguards and reviews them on an ongoing basis, including access control, device security, internal rules and training, and supervision of processors where applicable.

---

## 3. Privacy Policy (core)

### (1) Collection

Information is collected through lawful and fair means, such as contact forms, email, and contractual processes.

### (2) Cookies

Cookies or similar technologies may be used for usability and access analytics. They are not used to identify individuals for unrelated purposes.

### (3) Retention

Data is retained only as long as necessary for the purposes of use or as required by law, then deleted or anonymized appropriately.

### (4) Requests for disclosure / correction / deletion

Requests from individuals are handled in accordance with applicable law.
