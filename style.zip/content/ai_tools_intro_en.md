This page combines **dashboard shortcuts** (key tools) and a **tool catalog** for local demos and reference analysis.
