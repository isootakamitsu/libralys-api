## What is Real Estate Appraisal?

**Real estate appraisal** is a disciplined process to explain property value *with reasons*—not merely to state a number.  
It produces an **Appraisal Report** that a third party can review, for example for secured lending, court proceedings, audit support, or corporate governance.

*Libralys is not currently registered as a designated real estate appraisal firm under the Japanese Real Estate Appraisal Act; statutory appraisal services under that Act are therefore not provided.*

## Why do “prices” diverge?

Real property values are sensitive to **assumptions**. When assumptions change, conclusions change.

Examples:
- Valuation date (as-of date)  
- Use status (owner-occupied vs. leased)  
- Legal interests (leasehold, tenancy, co-ownership, etc.)  
- Market conditions (interest rates, rents, supply/demand)

Libralys explains value as a **traceable structure** so misunderstandings are less likely.

## What does AI do here?

AI is **not** an autonomous pricing engine. At Libralys, AI assists the **Real Property Appraiser** by:
- Structuring public data with clear sourcing and scope  
- Supporting sensitivity analysis (how value moves when assumptions change)  
- Helping detect outliers and inconsistencies  

Final judgment and accountability rest with the real property appraiser.
