## Role

AI at Libralys does **not** replace the judgment of a real property appraiser.  
It supports transparency and reproducibility through data organization and consistency checks.  
Final conclusions and accountability remain with the appraiser.

## Use cases

- Structuring public statistics and comparables (source, period, geography, scope)  
- Sensitivity analysis (how value responds to assumption changes)  
- Consistency checks (outliers, contradictions, reconciliation with **Official Land Price Data**)  
- Communication support (making the valuation narrative easier to follow)

## Non-goals

- No standalone “automated appraisal” claims  
- No adoption of unknown or unverifiable data as primary evidence  
- No presentation of results without explicit assumptions and limitations

## Governance

- Source transparency for all referenced data  
- Reproducibility where practicable (assumptions, methods, adjustments)  
- Explicit limitations (legal interests, special circumstances, model boundaries)
