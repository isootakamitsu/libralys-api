Libralys presents experience not as a simple list of deliverables, but as **examples of decision-grade explanatory structure**.  
Even when addresses and numbers must remain confidential, the analytical approach can still be shared transparently.

---

## Case 1｜Collateral file (third-party explanation)

**概要**：Start from recipient requirements; make method choice and reconciliation **traceable** to reduce explanation friction.

### 設計上の焦点

- Recipient checklist
- As-of date and **Highest and Best Use** pinned early
- Traceable adjustment path
- Reconciliation with **Official Land Price Data** and market evidence

*Locations and figures are anonymized for confidentiality.*

---

## Case 2｜Inheritance

**概要**：Scenario-map how rights and use affect value—shifting debate from “the number” to “the assumptions.”

### 設計上の焦点

- Rights and interests
- Multiple transparent scenarios
- Narrative structure for non-experts
- Reducing preventable misunderstandings

*Not a substitute for tax advice; supports informed agreement.*

---

## Case 3｜Litigation rent opinion (evidence & consistency)

**概要**：For contested rent levels, align differential allocation, yield, and market comparables into a coherent evidence package.

### 設計上の焦点

- Fixed premises (lease, use, micro-location)
- Cross-checked methods
- Reconciliation to market data
- Visible calculation trail and explicit limits

*Neutrality is maintained regardless of client preference.*
