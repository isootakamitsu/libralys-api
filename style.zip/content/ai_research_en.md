## 1. Research philosophy

Libralys treats AI not only as an efficiency tool, but as technology that can improve **transparency of valuation structure**.

The AI valuation research group develops practice-integrated models aligned with the **Japanese Real Estate Appraisal Standards**.

## 2. Major research themes (examples)

- AIGRAF (AI–GEO Real Estate Consulting Framework)  
- SHAP-based visualization of price drivers  
- Yield design grounded in r–g structures  
- Algorithms supporting adjustment-rate workflows  
- Disaster scenario valuation models  
- ESG-integrated considerations  

## 3. Model structure (examples)

- XGBoost regression  
- SHAP decomposition for interpretability  
- Time-series adjustment indices  
- GIS-linked spatial layers  
- Integrated sensitivity analysis  
