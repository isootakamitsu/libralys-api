## 1. Initial consultation

We begin by clarifying the question. Clients often need more than a number—they need an explanation that will stand up to third-party review.

We confirm the mandate (sale, collateral, inheritance, dispute, etc.), recipient requirements, timeline, and a concise property profile (use, tenancy, rights).
We then outline likely issues and a document roadmap.
*(Libralys is not currently registered to provide statutory appraisal services under the Japanese Real Estate Appraisal Act.)*

## 2. Scope, fee, and schedule

We define deliverables, depth of investigation, site inspection needs, and recipient expectations—then propose fees, process, and timing.

Where independence or quality cannot be maintained, we decline the engagement. For a compact practice, this gatekeeping is core quality control.

## 3. Site inspection

Real property always contains facts that desktop research cannot capture: access, neighborhood context, occupancy, relationships with surroundings, and physical condition.

Where site work is material to accountability, we treat inspection as part of the evidence base—not an optional extra.

## 4. Market analysis and assisted analytics (including AI)

We organize comparables, **Official Land Price Data**, rent/yield context, and market narratives.

AI is not used to “decide” value. It assists with:
- structuring open data with traceable sourcing
- sensitivity analysis (how conclusions move when assumptions move)
- consistency checks (outliers and contradictions)

The objective is to make professional judgment **reviewable**, not to replace it.

## 5. Reporting structure

Following the **Japanese Real Estate Appraisal Standards**, we structure work from valuation purpose and as-of date through **Highest and Best Use**,
method selection, adjustments, reconciliation, and explicit limitations—so readers know where to find the audit trail.
*(Statutory appraisal services under the Japanese Act are not currently provided.)*

## 6. Delivery and explanation

Consulting value is realized only when decision-makers understand the result.

We explain the calculation architecture, assumptions, meaning of the conclusion, and boundaries. Where helpful, we add sensitivity supplements to reduce misunderstanding.

---

## Frequently asked questions

*Representative questions on appraisal and consulting*


### Q1. Appraisal vs. brokerage pricing opinions?

Brokerage guidance often targets a marketing range. **Real Estate Appraisal** under Japanese standards produces an **Appraisal Report** intended for third-party scrutiny.
*(Libralys is not currently registered to provide statutory appraisal services under the Japanese Act.)*


### Q2. How long does it take?

Typically on the order of two to three weeks, depending on scale and data availability.


### Q3. How are fees determined?

By scale, use, purpose, and documentation burden. We provide a written estimate before formal engagement.


### Q4. Can outputs be used for lenders?

We routinely support collateral, M&A, inheritance, and restructuring contexts—aligned to recipient requirements.


### Q5. Is a site visit mandatory?

As a rule, yes. Desktop-only work is exceptional where it is demonstrably reasonable and adequately disclosed.


### Q6. Can negative-income property be analyzed?

Yes. **Discounted Cash Flow (DCF) Analysis** and income restructuring are common tools—always with explicit scenarios.


### Q7. Land-only assignments?

Yes—including vacant land, underlying land, and leasehold interests—subject to rights and use assumptions.


### Q8. Undivided co-ownership interests?

Yes, reflecting marketability discounts and disposal constraints where material.


### Q9. Future price forecasts?

Scenario analysis is possible; it is not a guarantee of future market outcomes.


### Q10. Do you ever decline work?

Yes—where conflicts of interest or quality assurance cannot be maintained.
